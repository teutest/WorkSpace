$(function(){
	
	// 서버로 받아 온 코드값에 대한 처리 함수(login.jsp 파일에 정의)
	errCodeCheck()
	$('#u_id, #u_pw').bind("keyup",function(){
		$(this).parents("div").find(".error").html("");
	});
	
	// 로그인 버튼 클릭 시 처리 이벤트
	$("#loginBtn").click(function(){
		// 입력값 체크
		if(!chkSubmit($('#u_id'), "아이디를")) {
			return;
		} else if (!chkSubmit($('#u_pw'), "비밀번호를")) {
			return;
		} else if (confirm('로그인하시겠습니까 ?')){
			$('#loginForm').attr({
					"method" : "POST",
					"action" : "/login/login"
				});
				$('#loginForm').submit();
		}
	});
	
	
	/* 입력 필요한 항목 입력했는지 체크 */
	function chkSubmit(item, msg) {
		if (item.val().replace(/\s/g, "") == "") {
			alert(msg + " 입력해주세요.");
			item.val("");
			item.focus();
			return false;
		} else {
			return true;
		}
	}
});