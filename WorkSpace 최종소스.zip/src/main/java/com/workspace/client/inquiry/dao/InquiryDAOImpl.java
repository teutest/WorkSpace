package com.workspace.client.inquiry.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.workspace.client.inquiry.vo.InquiryVO;

@Repository
public class InquiryDAOImpl implements InquiryDAO {
	
	@Autowired
	private SqlSession session;
	
	@Override
	public List<InquiryVO> inquiryClientList(Map<String, Integer> pagingMap) {
		
		return session.selectList("inquiryClientList", pagingMap);
	}

	@Override
	public int totClientInquiryList() {
		return session.selectOne("totClientInquiryList");
	}

	@Override
	public InquiryVO inquiryClientDetail(int i_num) {
		
		return session.selectOne("inquiryClientDetail", i_num);
	}

	@Override
	public int inquiryInsert(InquiryVO ivo) {
		return session.insert("inquiryInsert", ivo);
	}

	@Override
	public int maxI_num() {
		return session.selectOne("maxI_num");
	}

}
