package com.workspace.client.inquiry.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.workspace.client.inquiry.dao.InquiryDAO;
import com.workspace.client.inquiry.vo.InquiryVO;

@Service
@Transactional
public class InquiryServiceImpl implements InquiryService {
	
	@Autowired
	private InquiryDAO inquiryDAO;
	
	@Override
	//문의게시판 리스트 출력
	public Map<String, Object> inquiryClientList(Map<String, Integer> pagingMap) {
		
		Map<String, Object> inquiryClientListMap = new HashMap<String, Object>();
		
		//문의게시판 리스트 출력
		List<InquiryVO> inquiryClientList = inquiryDAO.inquiryClientList(pagingMap);
		
		//전체 문의게시판 리스트 수 조회
		int totClientInquiryList = inquiryDAO.totClientInquiryList();
		
		inquiryClientListMap.put("inquiryClientList",inquiryClientList);
		inquiryClientListMap.put("totClientInquiryList", totClientInquiryList);
		
		return inquiryClientListMap;
	}

	@Override
	//글 상세보기
	public InquiryVO inquiryClientDetail(int i_num) {
		
		return inquiryDAO.inquiryClientDetail(i_num);
	}
	
	//글쓰기
	@Override
	public int inquiryInsert(InquiryVO ivo) {
		int result = 0;
		try {
			ivo.setI_num(inquiryDAO.maxI_num() + 1);
			result = inquiryDAO.inquiryInsert(ivo);
		}catch(Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}	

}
