package com.workspace.client.inquiry.dao;

import java.util.List;
import java.util.Map;

import com.workspace.client.inquiry.vo.InquiryVO;

public interface InquiryDAO {
	
	// 문의게시판 리스트 출력
	public List<InquiryVO> inquiryClientList(Map<String, Integer> pagingMap);
	
	//전체 문의게시판 리스트 수 조회
	public int totClientInquiryList();
	
	//글 상세보기
	public InquiryVO inquiryClientDetail(int i_num);
	
	//글 쓰기
	public int inquiryInsert(InquiryVO ivo);
	
	//가장 최신 문의글 번호 조회
	public int maxI_num();
	
	
}
