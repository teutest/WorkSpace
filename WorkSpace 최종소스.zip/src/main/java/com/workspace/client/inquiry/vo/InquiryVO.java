package com.workspace.client.inquiry.vo;

import java.util.Date;

public class InquiryVO {
	private int level;
	private int i_num;
	private int i_parent_num;
	private String i_name;
	private String i_title;
	private String i_content;
	private String i_photo;
	private String i_reply;
	private Date i_reg;
	
	
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public int getI_num() {
		return i_num;
	}
	public void setI_num(int i_num) {
		this.i_num = i_num;
	}
	public int getI_parent_num() {
		return i_parent_num;
	}
	public void setI_parent_num(int i_parent_num) {
		this.i_parent_num = i_parent_num;
	}
	public String getI_name() {
		return i_name;
	}
	public void setI_name(String i_name) {
		this.i_name = i_name;
	}
	public String getI_title() {
		return i_title;
	}
	public void setI_title(String i_title) {
		this.i_title = i_title;
	}
	public String getI_content() {
		return i_content;
	}
	public void setI_content(String i_content) {
		this.i_content = i_content;
	}
	public String getI_photo() {
		return i_photo;
	}
	public void setI_photo(String i_photo) {
		this.i_photo = i_photo;
	}
	public String getI_reply() {
		return i_reply;
	}
	public void setI_reply(String i_reply) {
		this.i_reply = i_reply;
	}
	public Date getI_reg() {
		return i_reg;
	}
	public void setI_reg(Date i_reg) {
		this.i_reg = i_reg;
	}
	@Override
	public String toString() {
		return "InquiryVO [i_num=" + i_num + ", i_parent_num=" + i_parent_num + ", i_name="
				+ i_name + ", i_title=" + i_title + ", i_content=" + i_content + ", i_photo="
				+ i_photo + ", i_reply=" + i_reply + ", i_reg=" + i_reg + "]";
	}
	
}
