package com.workspace.client.inquiry.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.workspace.client.inquiry.service.InquiryService;
import com.workspace.client.inquiry.vo.InquiryVO;

@Controller
@RequestMapping(value = "/inquiry")
public class InquiryController {

	@Autowired
	private InquiryService inquiryService;

	/* 글목록 구현하기 */
	@RequestMapping(value = "/inquiryClientList", method = RequestMethod.GET)
	public String inquiryClientList(HttpServletRequest request, Model model) {

		String _section = request.getParameter("section");
		String _pageNum = request.getParameter("pageNum");

		int section = Integer.parseInt(((_section == null) ? "1" : _section));
		int pageNum = Integer.parseInt(((_pageNum == null) ? "1" : _pageNum));

		System.out.println("서비스전 섹션 수" + section);
		System.out.println("서비스전 페이지 수" + pageNum);

		Map<String, Integer> pagingMap = new HashMap<String, Integer>();
		pagingMap.put("section", section);
		pagingMap.put("pageNum", pageNum);

		System.out.println(pagingMap.get("section"));
		System.out.println(pagingMap.toString());

		Map<String, Object> inquiryClientListMap = inquiryService.inquiryClientList(pagingMap);
		inquiryClientListMap.put("section", section);
		inquiryClientListMap.put("pageNum", pageNum);

		model.addAttribute("inquiryClientListMap", inquiryClientListMap);

		return "inquiry/clientInquiryList";
	}

	// 문의글 상세보기
	@RequestMapping(value = "/inquiryClientDetail", method = RequestMethod.GET)
	public String inquiryClientDetail(@RequestParam("i_num") String i_num, HttpServletRequest request, Model model) {
		
		InquiryVO ivo = inquiryService.inquiryClientDetail(Integer.parseInt(i_num));
		
		model.addAttribute("ivo", ivo);
		
		return "inquiry/clientInquiryDetail";
	}
	
	//문의글쓰기 폼 출력하기
	@RequestMapping(value="/inquiryWriteForm")
	public String inquiryWriteForm() {
		return "inquiry/inquiryWriteForm";
	}
	
	//문의글쓰기 구현하기
	@RequestMapping(value="/inquiryInsert", method=RequestMethod.POST)
	public String inquiryInsert(@ModelAttribute InquiryVO ivo, Model model) throws IllegalStateException, IOException{
		
		ivo.setI_parent_num(0);
		ivo.setI_reply("미답변");
		
		int result = inquiryService.inquiryInsert(ivo);
		if(result == 1) {
			return "redirect:/inquiry/inquiryClientList";
		}
		return "redirect:/inquiry/inquiryWriteForm";
	}
		
}
