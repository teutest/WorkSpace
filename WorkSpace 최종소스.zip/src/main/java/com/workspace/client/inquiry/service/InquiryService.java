package com.workspace.client.inquiry.service;

import java.util.Map;

import com.workspace.client.inquiry.vo.InquiryVO;

public interface InquiryService {
	//문의게시판 리스트 출력
	public Map<String, Object> inquiryClientList(Map<String, Integer> pagingMap);
	
	//문의게시판 상세보기
	public InquiryVO inquiryClientDetail(int i_num);
	
	//문의게시판 글쓰기
	public int inquiryInsert(InquiryVO ivo);
	
}
	
	
