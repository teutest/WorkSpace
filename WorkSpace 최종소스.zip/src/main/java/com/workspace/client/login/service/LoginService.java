package com.workspace.client.login.service;

import javax.servlet.http.HttpServletResponse;

import com.workspace.client.login.vo.LoginVO;

public interface LoginService {

	public LoginVO login(LoginVO lvo);		// 로그인 처리
	public String findId(String u_name, String u_email);	// 아이디 찾기
	public void findPw(HttpServletResponse response, LoginVO lvo) throws Exception; // 비밀번호 찾기
	public void sendEmail(LoginVO lvo, String div) throws Exception;	// 이메일 발송

}
