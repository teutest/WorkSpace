package com.workspace.client.login.controller;

import javax.mail.Session;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.workspace.client.common.util.OpenCrypt;
import com.workspace.client.login.service.LoginService;
import com.workspace.client.login.vo.LoginVO;
import com.workspace.client.member.service.MemberService;
import com.workspace.client.member.vo.MemberSecurity;
import com.workspace.client.member.vo.MemberVO;

@Controller
@RequestMapping("/login")
public class LoginController {
	private Logger log = LoggerFactory.getLogger(LoginController.class);

	@Autowired
	private LoginService loginService;
	
	@Autowired
	private MemberService memberService;

	// 로그인 페이지 보여주기
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String LoginPage() {
			
		return "login/login";
	}
	
	// 로그인 처리
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView login(@ModelAttribute("LoginVO") LoginVO lvo, HttpSession session, HttpServletRequest request) {

		log.info("login 호출 성공");

		ModelAndView mav = new ModelAndView();
		LoginVO pass = new LoginVO();

		LoginVO login = loginService.login(lvo);
		
		// id로 scurity_tbl에서 salt값 조회
		MemberSecurity sec = memberService.findSalt(lvo.getU_id());
		
		if (sec == null) { // 아이디 틀릴 경우
			session.setAttribute("u_id", null);
			mav.addObject("errCode", 1); 
			mav.setViewName("login/login"); 
			return mav;
		}
		
		// 암호화 처리
		pass.setU_pw(new String(OpenCrypt.getSHA256(lvo.getU_pw(), sec.getSalt())));
		
		System.out.println(pass.getU_pw());
		System.out.println("db 암호화비번 : " + login.getU_pw());
		
		/*
		 * member_tbl에 있는 암호화된 u_pw와 로그인창에서 
		 * 입력한 비밀번호를 암호화 처리 후 비교
		 */
		if(login != null && login.getU_pw().equals(pass.getU_pw())) { // 로그인 성공 시
			session.setAttribute("u_id", login.getU_id());
			mav.setViewName("home"); 
			return mav;
		} else { // 로그인 실패 시
			session.setAttribute("u_id", null);
			mav.addObject("errCode", 1); 
			mav.setViewName("login/login"); 
			return mav;
		}
	}

	// 아이디/비밀번호 찾기 페이지 보여주기
	@RequestMapping(value = "/find", method = RequestMethod.GET)
	public String findPage() {
		return "login/find";
	}

	// 아이디 찾기
	@ResponseBody
	@RequestMapping(value = "/findId", method = RequestMethod.POST)
	public String findID(@RequestParam("u_name") String u_name, @RequestParam("u_email") String u_email) {

		String result = loginService.findId(u_name, u_email);

		return result;

	}

	// 비밀번호 찾기
	@ResponseBody
	@RequestMapping(value = "/findPw", method = RequestMethod.POST)
	public void findPw(@ModelAttribute() LoginVO lvo, HttpServletResponse response) throws Exception {
		
		loginService.findPw(response, lvo);
		
	}

	// 로그아웃 처리
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession session, HttpServletRequest request) {
		session.invalidate();
		session = request.getSession(true);
		
		return "redirect:/";
	}

}
