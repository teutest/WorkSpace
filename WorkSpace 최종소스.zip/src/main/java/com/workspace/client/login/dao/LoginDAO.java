package com.workspace.client.login.dao;

import java.util.Map;

import com.workspace.client.login.vo.LoginVO;

public interface LoginDAO {

	public LoginVO login(LoginVO lvo);	// 로그인

	public String findId(Map<String, Object> map);// 아이디 찾기

	public int updatePw(LoginVO lvo) throws Exception; // 비밀번호 변경

	



	



}
