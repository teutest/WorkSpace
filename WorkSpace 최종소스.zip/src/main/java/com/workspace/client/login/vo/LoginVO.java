package com.workspace.client.login.vo;

public class LoginVO {
	private String u_id = ""; // 아이디
	private String u_pw = ""; // 비밀번호
	private String u_email = ""; // 담당자 이메일
	private String u_name = "";	// 담당자 이름
	private String deactivated = ""; // 비활성화 여부

	public String getDeactivated() {
		return deactivated;
	}

	public void setDeactivated(String deactivated) {
		this.deactivated = deactivated;
	}

	public LoginVO() {
		super();
	}

	public LoginVO(String u_id, String u_pw, String u_email) {
		super();
		this.u_id = u_id;
		this.u_pw = u_pw;
		this.u_email = u_email;
	}

	public String getU_id() {
		return u_id;
	}

	public void setU_id(String u_id) {
		this.u_id = u_id;
	}

	public String getU_pw() {
		return u_pw;
	}

	public void setU_pw(String u_pw) {
		this.u_pw = u_pw;
	}

	public String getU_email() {
		return u_email;
	}

	public void setU_email(String u_email) {
		this.u_email = u_email;
	}

	public String getU_name() {
		return u_name;
	}

	public void setU_name(String u_name) {
		this.u_name = u_name;
	}

}
