package com.workspace.client.login.service;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.mail.HtmlEmail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.workspace.client.common.util.OpenCrypt;
import com.workspace.client.login.dao.LoginDAO;
import com.workspace.client.login.vo.LoginVO;
import com.workspace.client.member.dao.MemberDAO;
import com.workspace.client.member.vo.MemberSecurity;
import com.workspace.client.member.vo.MemberVO;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LoginDAO loginDAO;

	@Autowired
	private MemberDAO memberDAO;

	// 로그인 처리
	@Override
	public LoginVO login(LoginVO lvo) {
		LoginVO vo = null;

		vo = loginDAO.login(lvo);

		return vo;
	}

	// 아이디 찾기
	@Override
	public String findId(String u_name, String u_email) {
		String result = "";

		Map<String, Object> map = new HashMap<>();

		map.put("u_name", u_name);
		map.put("u_email", u_email);

		result = loginDAO.findId(map);

		return result;
	}

	// 비밀번호 찾기
	@Override
	public void findPw(HttpServletResponse response, LoginVO lvo) throws Exception  {
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		String u_id = lvo.getU_id();

		System.out.println("가져온 id :"+u_id);
		MemberVO mvo = memberDAO.readMember(u_id);
		
		// 가입된 아이디 없으면
		if (memberDAO.readMember(u_id) == null) {
			out.print("등록되지 않은 아이디입니다.");
			out.close();
			
		} else if (!lvo.getU_name().equals(mvo.getU_name())) { // 가입된 이름과 다르면
			out.print("등록되지 않은 이름입니다."); 
			out.close();
			
		} else if (!lvo.getU_email().equals(mvo.getU_email())) { // 가입된 이메일 아니면
			out.print("등록되지 않은 이메일입니다.");
			out.close();

		} else { // 임시 비밀번호 생성
			String pw = "";
			for (int i = 0; i < 12; i++) {
				pw += (char) ((Math.random() * 26) + 97);
			}
			
			lvo.setU_pw(pw);
			// 비밀번호 변경 메일 발송
			sendEmail(lvo, "findPw");
			
			// id로 scurity_tbl에서 salt값 조회
			MemberSecurity sec = memberDAO.findSalt(lvo.getU_id());

			// 암호화 처리 
			lvo.setU_pw(new String(OpenCrypt.getSHA256(pw, sec.getSalt())));
			
			// 비밀번호 변경
			loginDAO.updatePw(lvo);

			out.print("이메일로 임시 비밀번호를 발송하였습니다.");
			out.close();
			
		}
		
	}

	// 이메일 발송
	@Override
	public void sendEmail(LoginVO lvo, String div) throws Exception {
		// Mail Server 설정
		String charSet = "utf-8";
		String hostSMTP = "smtp.gmail.com";
		String hostSMTPid = "teutest2011@gmail.com";
		String hostSMTPpwd = "zzmnpwaljzjvwglc";

		// 보내는 사람 이메일 주소
		String fromEmail = "teutest2011@gmail.com";
		String fromName = "WorkSpace";
		String subject = "";
		String msg = "";

		if (div.equals("findPw")) {
			subject = "WorkSpace 임시 비밀번호 입니다.";
			msg += "<div align='center' style='border:1px solid black; font-size:20px;'>";
			msg += lvo.getU_id() + "님의 임시 비밀번호 입니다. 비밀번호를 변경하여 사용하세요.";
			msg += "<p>임시 비밀번호 : ";
			msg += "<span style='font-size:25px; font-weight:bold;'>" +lvo.getU_pw()  + "</span></p><div>";
		}

		// 받는 사람 email 주소
		String mail = lvo.getU_email();

		try {
			HtmlEmail email = new HtmlEmail();
			email.setDebug(true);
			email.setCharset(charSet);
			email.setSSL(true);
			email.setHostName(hostSMTP);
			email.setSmtpPort(465);

			email.setAuthentication(hostSMTPid, hostSMTPpwd);
			email.setTLS(true);
			email.addTo(mail, charSet);
			email.setFrom(fromEmail, fromName, charSet);
			email.setSubject(subject);
			email.setHtmlMsg(msg);
			email.send();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
