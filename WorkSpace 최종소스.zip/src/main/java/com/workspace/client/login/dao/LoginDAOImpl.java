package com.workspace.client.login.dao;

import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.workspace.client.login.vo.LoginVO;

@Repository
public class LoginDAOImpl implements LoginDAO {

	@Autowired
	private SqlSession session;
	
	// 로그인 처리
	@Override
	public LoginVO login(LoginVO lvo) {
		
		return (LoginVO) session.selectOne("login",lvo);
	}

	// 아이디 찾기
	@Override
	public String findId(Map<String, Object> map) {
		return session.selectOne("findId", map);
	}

	// 비밀번호 변경
	@Override
	public int updatePw(LoginVO lvo) throws Exception {
		return session.update("com.workspace.client.login.dao.LoginDAO.updatePw",lvo);
		
	}

}
