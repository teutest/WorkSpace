package com.workspace.client.notice.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.workspace.client.notice.vo.NoticeVO;

@Repository
public class NoticeDAOImpl implements NoticeDAO {
	
	@Autowired
	private SqlSession session;
	
	// 글 목록 조회
	@Override
	public List<NoticeVO> noticeList(NoticeVO nvo) {
		
		return session.selectList("noticeList", nvo);
	}

	// 글 상세보기
	@Override
	public NoticeVO noticeDetail(NoticeVO nvo) {
		
		return session.selectOne("noticeDetail", nvo);
	}

	@Override
	public int noticeListCnt(NoticeVO nvo) {
		
		return (Integer)session.selectOne("noticeListCnt");
	}

}
