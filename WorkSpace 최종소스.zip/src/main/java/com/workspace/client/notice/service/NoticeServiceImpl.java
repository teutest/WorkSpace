package com.workspace.client.notice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.workspace.client.notice.dao.NoticeDAO;
import com.workspace.client.notice.vo.NoticeVO;
@Service
@Transactional
public class NoticeServiceImpl implements NoticeService {

	@Autowired
	private NoticeDAO noticeDAO;
	
	// 글 목록 조회
	@Override
	public List<NoticeVO> noticeList(NoticeVO nvo) {
		List<NoticeVO> nList = null;
		
		nList = noticeDAO.noticeList(nvo);
		
		return nList;
	}
	
	// 글 상세보기
	@Override
	public NoticeVO noticeDetail(NoticeVO nvo) {
		NoticeVO detail = null;
		
		detail = noticeDAO.noticeDetail(nvo);
		
		return detail;
	}
	
	// 전체 레코드 수 구현
	@Override
	public int noticeListCnt(NoticeVO nvo) {
		
		return noticeDAO.noticeListCnt(nvo);
	}

}
