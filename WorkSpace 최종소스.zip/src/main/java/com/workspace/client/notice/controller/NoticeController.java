package com.workspace.client.notice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.workspace.client.common.page.Paging;
import com.workspace.client.common.util.Util;
import com.workspace.client.notice.service.NoticeService;
import com.workspace.client.notice.vo.NoticeVO;

@Controller
@RequestMapping(value = "/notice")
public class NoticeController {

	@Autowired
	NoticeService noticeService;

	// 글 목록 구현하기
	@RequestMapping(value = "/noticeList", method = RequestMethod.GET)
	public String noticeList(@ModelAttribute NoticeVO nvo, Model model) {
		System.out.println("noticeList 호출 성공");
		int total = 0;
		int count = 0;

		// 페이지 세팅	 string -> int로 바꿔서 set함
		Paging.setPage(nvo);
		
		if (nvo.getKeyword() == "") {	// 전체 조회일 경우

			// 전체 레코드 수 구현
			total = noticeService.noticeListCnt(nvo);
			System.out.println("total = " + total);

		} else {	// 검색을 했을 경우 

			// 전체 레코드 수 구현
			int start_row = Integer.parseInt(nvo.getStart_row());
			int end_row = Integer.parseInt(nvo.getEnd_row());

			total = end_row - start_row;

		}

		// 글번호 재설정
		count = total - (Util.nvl(nvo.getPage())-1) * Util.nvl(nvo.getPageSize());
		
		List<NoticeVO> noticeList = noticeService.noticeList(nvo);

		model.addAttribute("noticeList", noticeList);
		model.addAttribute("total", total);
		model.addAttribute("count", count);
		model.addAttribute("data", nvo);

		return "notice/noticeList";
	}

	// 글 상세보기 구현
	@RequestMapping(value = "/noticeDetail", method = RequestMethod.GET)
	public String NoticeDetail(@ModelAttribute NoticeVO nvo, Model model) {
		System.out.println("noticeDetail 호출 성공");

		NoticeVO detail = new NoticeVO();

		detail = noticeService.noticeDetail(nvo);

		if (detail != null) {
			detail.setN_content(detail.getN_content().toString().replaceAll("\n", "<br>"));
		}

		model.addAttribute("detail", detail);

		return "notice/noticeDetail";

	}

}
