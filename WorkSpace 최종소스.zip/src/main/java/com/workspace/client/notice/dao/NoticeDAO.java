package com.workspace.client.notice.dao;

import java.util.List;

import com.workspace.client.notice.vo.NoticeVO;

public interface NoticeDAO {

	List<NoticeVO> noticeList(NoticeVO nvo);			// 글 목록 조회
	NoticeVO noticeDetail(NoticeVO nvo);	// 글 상세보기
	int noticeListCnt(NoticeVO nvo);

}
