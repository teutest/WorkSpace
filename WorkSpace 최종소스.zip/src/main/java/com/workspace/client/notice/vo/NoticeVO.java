package com.workspace.client.notice.vo;

import com.workspace.client.common.vo.CommonVO;

public class NoticeVO extends CommonVO {
	private int n_num = 0; // 글번호
	private String n_title = ""; // 글 제목
	private String n_content = ""; // 글 내용
	private String n_reg = ""; // 글 등록일
	private String n_photo = ""; // 사진

	public NoticeVO() {
		super();
	}

	public NoticeVO(int n_num, String n_title, String n_content, String n_reg, String n_photo) {
		super();
		this.n_num = n_num;
		this.n_title = n_title;
		this.n_content = n_content;
		this.n_reg = n_reg;
		this.n_photo = n_photo;
	}

	public int getN_num() {
		return n_num;
	}

	public void setN_num(int n_num) {
		this.n_num = n_num;
	}

	public String getN_title() {
		return n_title;
	}

	public void setN_title(String n_title) {
		this.n_title = n_title;
	}

	public String getN_content() {
		return n_content;
	}

	public void setN_content(String n_content) {
		this.n_content = n_content;
	}

	public String getN_reg() {
		return n_reg;
	}

	public void setN_reg(String n_reg) {
		this.n_reg = n_reg;
	}

	public String getN_photo() {
		return n_photo;
	}

	public void setN_photo(String n_photo) {
		this.n_photo = n_photo;
	}

}
