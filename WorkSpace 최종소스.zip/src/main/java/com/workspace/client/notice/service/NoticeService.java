package com.workspace.client.notice.service;

import java.util.List;

import com.workspace.client.notice.vo.NoticeVO;

public interface NoticeService {

	List<NoticeVO> noticeList(NoticeVO nvo);			// 글 목록 조회
	NoticeVO noticeDetail(NoticeVO nvo);	// 글 상세보기
	int noticeListCnt(NoticeVO nvo);

}
