package com.workspace.client.common.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MainController {
	@RequestMapping(value="/", method=RequestMethod.GET)
	public String main() {
		return "index";
	}
	
	// 인사말 페이지
	@RequestMapping(value="/greeting/greetingPage")
	public String greeting() {
		return "greeting/greetingPage";
	}
	
	// 사용가이드 페이지
	@RequestMapping(value="/guide/guidePage")
	public String userGuide() {
		return "guide/guidePage";
	}
	
	// 개인정보취급방침 페이지
	@RequestMapping(value="/terms/termsPage1")
	public String termsPage1() {
		return "terms/termsPage1";
	}
	
	// 이용약관 페이지
	@RequestMapping(value="/terms/termsPage2")
	public String termsPage2() {
		return "terms/termsPage2";
	}
	
	
	
}
