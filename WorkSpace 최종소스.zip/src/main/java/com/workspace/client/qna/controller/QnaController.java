package com.workspace.client.qna.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.workspace.client.qna.service.QnaService;
import com.workspace.client.qna.vo.QnaVO;

@Controller
@RequestMapping(value = "/qna")
public class QnaController {
	
	
	 @Autowired private QnaService qnaService; 
	 
	
	// Qna 리스트 페이지 출력
	@RequestMapping(value = "/qnaList", method = RequestMethod.GET)
	public String qnaList(Model model) {
		System.out.println("QnaList 호출 성공");
		
		List<QnaVO> qnaList = qnaService.clientQnaList();
		
		model.addAttribute("qnaList",qnaList);
		
		return "qna/qnaList";
	}
	
	
	
}
