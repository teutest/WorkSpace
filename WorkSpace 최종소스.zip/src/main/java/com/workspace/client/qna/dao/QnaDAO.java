package com.workspace.client.qna.dao;

import java.util.List;

import com.workspace.client.qna.vo.QnaVO;

public interface QnaDAO {

	// QnaList 출력
	List<QnaVO> clientQnaList();

}
