package com.workspace.client.qna.service;

import java.util.List;

import com.workspace.client.qna.vo.QnaVO;

public interface QnaService {

	// qnaList 출력
	List<QnaVO> clientQnaList();

}
