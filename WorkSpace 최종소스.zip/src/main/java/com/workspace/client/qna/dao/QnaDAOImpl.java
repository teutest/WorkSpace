package com.workspace.client.qna.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.workspace.client.qna.vo.QnaVO;
@Repository
public class QnaDAOImpl implements QnaDAO {

	@Autowired SqlSession session;
	
	// QnaList 출력
	@Override
	public List<QnaVO> clientQnaList() {
		
		return session.selectList("clientQnaList");
	}

}
