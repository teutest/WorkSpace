package com.workspace.client.qna.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.workspace.client.qna.dao.QnaDAO;
import com.workspace.client.qna.vo.QnaVO;

@Service
public class QnaServiceImpl implements QnaService {

	@Autowired QnaDAO qnaDAO;
	
	// qnaList 출력
	@Override
	public List<QnaVO> clientQnaList() {
		
		return qnaDAO.clientQnaList();
	}

}
