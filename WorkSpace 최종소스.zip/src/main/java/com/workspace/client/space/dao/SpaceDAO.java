package com.workspace.client.space.dao;

import java.util.List;

import com.workspace.client.reserve.vo.ReserveVO;
import com.workspace.client.space.vo.SpaceVO;

public interface SpaceDAO {
	public List<SpaceVO> spacePrivateList(String s_type);// 사무공간조회
	public SpaceVO spacePrivateDetail(SpaceVO svo);

	public List<SpaceVO> spacePublicList();
	public SpaceVO spacePublicDetail(SpaceVO svo);
	public List<ReserveVO> spacePublicHrs(ReserveVO rvo);
}
