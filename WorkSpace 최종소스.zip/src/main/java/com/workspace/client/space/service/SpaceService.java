package com.workspace.client.space.service;

import java.util.List;

import com.workspace.client.reserve.vo.ReserveVO;
import com.workspace.client.space.vo.SpaceVO;

public interface SpaceService {
	public List<SpaceVO> spacePrivateList(String s_type); // 라디오버튼 클릭시 조회
	public SpaceVO spacePrivateDetail(SpaceVO svo);
	
	public List<SpaceVO> spacePublicList();
	public SpaceVO spacePublicDetail(SpaceVO svo);
	public List<ReserveVO> spacePublicHrs(ReserveVO rvo);

}
