package com.workspace.client.space.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.workspace.client.reserve.vo.ReserveVO;
import com.workspace.client.space.dao.SpaceDAO;
import com.workspace.client.space.vo.SpaceVO;

@Service
@Transactional
public class SpaceServiceImpl implements SpaceService {

	@Autowired
	private SpaceDAO spaceDAO;

	// 사무공간 조회
	@Override
	public List<SpaceVO> spacePrivateList(String s_type) {
		List<SpaceVO> spacePrivateList = null;
		spacePrivateList = spaceDAO.spacePrivateList(s_type);
		return spacePrivateList;
	}

	// 사무공간 상세페이지 구현
	@Override
	public SpaceVO spacePrivateDetail(SpaceVO svo) {
		SpaceVO detail = null;
		detail = spaceDAO.spacePrivateDetail(svo);
		return detail;
	}
	
	
	//공용공간 조회
		@Override
		public List<SpaceVO> spacePublicList(){
			List<SpaceVO> spacePublicList = null;
			spacePublicList = spaceDAO.spacePublicList();
			return spacePublicList;
		}
		
		//공용공간 상세페이지
		@Override
		public SpaceVO spacePublicDetail(SpaceVO svo) {
			SpaceVO detail = null;
			detail = spaceDAO.spacePublicDetail(svo);
			return detail;
		}
		
		//공용 공간 예약된 시간 호출
			@Override
			public List<ReserveVO> spacePublicHrs(ReserveVO rvo) {
				List<ReserveVO> hrsList = null;
				hrsList = spaceDAO.spacePublicHrs(rvo);
				System.out.println(hrsList);
				
				return hrsList;
				
			}

}
