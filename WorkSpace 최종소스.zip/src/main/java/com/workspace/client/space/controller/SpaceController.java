package com.workspace.client.space.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.workspace.client.reserve.vo.ReserveVO;
import com.workspace.client.space.service.SpaceService;
import com.workspace.client.space.vo.SpaceVO;

@Controller

@RequestMapping(value = "/space")
public class SpaceController {
	private Logger log = LoggerFactory.getLogger(SpaceController.class);

	@Autowired
	private SpaceService spaceService;

	// 사무공간 리스트 구현
	@RequestMapping(value = "/spacePrivateList", method = RequestMethod.GET)
	public String SpaceSelectPrivateList(@RequestParam(value="s_type", required = false) String s_type,Model model) {
		log.info("SpaceSelectPrivateList 호출 성공");
		
		List<SpaceVO> spacePrivateList = spaceService.spacePrivateList(s_type);
		
		if(s_type == null) {
			model.addAttribute("s_type", "1인 데스크");
		} else {
			model.addAttribute("s_type", s_type);
		}
		
		model.addAttribute("spacePrivateList", spacePrivateList);

		return "space/SpacePrivateList";
	}

	/************************************************
	 * 사무공간 상세페이지 구현
	 ***********************************************/
	@RequestMapping(value = "/SpacePrivateDetail", method = RequestMethod.GET)
	public String spacePrivateDetail(@RequestParam("s_name") String s_name, Model model) {
		log.info("SpacePrivateDetail 호출 성공");

		SpaceVO svo = new SpaceVO();
		svo.setS_name(s_name);
		SpaceVO detail = spaceService.spacePrivateDetail(svo);

		if (detail != null && (!detail.equals(""))) {
			detail.setS_exp(detail.getS_exp().toString().replaceAll("\n", "<br>"));
		}

		model.addAttribute("detail", detail);
		return "space/SpacePrivateDetail";
	}
	
	/* 공용공간 사용가능한 시간 출력 ajax */
	@ResponseBody
	@RequestMapping(value = "/spacePublic", method = RequestMethod.GET)
	public String[] spacePublicHrs(@RequestParam("use_date") String use_date, @RequestParam("s_name") String s_name,
			Model model) {

		System.out.println(use_date);
		System.out.println(s_name);

		/* 공용공간 사용일을 가져와서 그 날짜에 사용가능시간을 불러오는 쿼리문을 작성해야한다. */
		/* 공용공간 예약(reserve dao)를 타고온 값을 가져온다. */

		ReserveVO rvo = new ReserveVO();
		rvo.setUse_date(use_date);
		rvo.setS_name(s_name);

		List<ReserveVO> reserved_hrs = spaceService.spacePublicHrs(rvo);

		System.out.println(reserved_hrs.toString());
		System.out.println(reserved_hrs.size());
		String[] available_hrs = new String[3];

		if (reserved_hrs.size() == 0) {
			available_hrs[0] = "오전";
			available_hrs[1] = "오후";
			available_hrs[2] = "전일제";
		} else if (reserved_hrs.size() == 1 && reserved_hrs.get(0).getHours().equals("전일제")) {
			available_hrs[0] = "사용불가";
		} else if (reserved_hrs.size() == 1 && reserved_hrs.get(0).getHours().equals("오후")) {
			available_hrs[0] = "오전";
		} else if (reserved_hrs.size() == 1 && reserved_hrs.get(0).getHours().equals("오전")) {
			available_hrs[0] = "오후";
		} else if (reserved_hrs.size() == 2 && reserved_hrs.get(0).getHours().equals("오후")
				&& reserved_hrs.get(1).getHours().equals("오전")) {
			available_hrs[0] = "사용불가";
		} else if (reserved_hrs.size() == 2 && reserved_hrs.get(0).getHours().equals("오전")
				&& reserved_hrs.get(1).getHours().equals("오후")) {
			available_hrs[0] = "사용불가";
		}

		for (int i = 0; i < available_hrs.length; i++) {
			System.out.println("가능 시간대" + available_hrs[i]);
		}

		return available_hrs;

	}
	
	/* 사용시간에 따라 공용공간 가격 바꾸는 ajax */
	@ResponseBody
	@RequestMapping(value = "/changePrice" , method = RequestMethod.GET )
	public String changePrice(@RequestParam("hours") String hours, Model model) {
		System.out.println("넘어오는 시간:" + hours);
		
		String price = "";
		if(!(hours.equals("전일제"))) {
			price = "300000";
		} else {
			price = "500000";
		}
		
		return price;
	}
	
	
	/* 공용공간 리스트 구현 */
	@RequestMapping(value = "/SpacePublicList", method = RequestMethod.GET)
	public String SpacePublicList(Model model, HttpServletRequest request) {
		System.out.println("spacePublicList 호출 성공");

		if (request.getSession().getAttribute("u_id") == null) {
			return "redirect:/login/login";
		}

		List<SpaceVO> spacePublicList = spaceService.spacePublicList();
		/*
		 * System.out.println(spacePublicList.get(0).getS_name());
		 * System.out.println(spacePublicList.get(0).getS_photo());
		 */

		model.addAttribute("spacePublicList", spacePublicList);
		model.addAttribute("u_id", request.getSession().getAttribute("u_id"));

		return "space/SpacePublicList";

	}

	/* 공용공간 상세페이지 구현 */
	@RequestMapping(value = "/SpacePublicDetail", method = RequestMethod.GET)
	public String spacePublicDetail(@RequestParam("s_name") String s_name, @RequestParam("u_id") String u_id,
			Model model) {
		System.out.println("spacePublicDetail 메서드 호출 성공");

		SpaceVO svo = new SpaceVO();
		svo.setS_name(s_name);
		SpaceVO detail = spaceService.spacePublicDetail(svo);

		model.addAttribute("detail", detail);

		return "space/SpacePublicDetail";
	}

}
