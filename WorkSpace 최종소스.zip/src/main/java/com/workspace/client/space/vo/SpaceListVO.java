package com.workspace.client.space.vo;

import java.util.List;

public class SpaceListVO {
	
	private List<SpaceVO> spaceList;

	public List<SpaceVO> getSpaceList() {
		return spaceList;
	}

	public void setSpaceList(List<SpaceVO> spaceList) {
		this.spaceList = spaceList;
	}
	
}
