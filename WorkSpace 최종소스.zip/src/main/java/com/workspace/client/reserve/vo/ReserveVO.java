package com.workspace.client.reserve.vo;

import com.workspace.client.member.vo.MemberVO;

public class ReserveVO {

	private int reserve_num;
	private String s_name;
	private String u_id;
	private String use_date;
	private String hours;
	private String reserve_state;
	private int total_cost;
	private String w_apply;
	private String w_state;
	private MemberVO memberVO;
	
	public int getReserve_num() {
		return reserve_num;
	}
	public void setReserve_num(int reserve_num) {
		this.reserve_num = reserve_num;
	}
	public String getS_name() {
		return s_name;
	}
	public void setS_name(String s_name) {
		this.s_name = s_name;
	}
	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	public String getUse_date() {
		return use_date;
	}
	public void setUse_date(String use_date) {
		this.use_date = use_date;
	}
	public String getHours() {
		return hours;
	}
	public void setHours(String hours) {
		this.hours = hours;
	}
	public String getReserve_state() {
		return reserve_state;
	}
	public void setReserve_state(String reserve_state) {
		this.reserve_state = reserve_state;
	}
	public int getTotal_cost() {
		return total_cost;
	}
	public void setTotal_cost(int total_cost) {
		this.total_cost = total_cost;
	}
	public String getW_apply() {
		return w_apply;
	}
	public void setW_apply(String w_apply) {
		this.w_apply = w_apply;
	}
	public String getW_state() {
		return w_state;
	}
	public void setW_state(String w_state) {
		this.w_state = w_state;
	}
	public MemberVO getMemberVO() {
		return memberVO;
	}
	public void setMemberVO(MemberVO memberVO) {
		this.memberVO = memberVO;
	}
	
	
}
