package com.workspace.client.reserve.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.workspace.client.reserve.vo.ReserveVO;

@Repository
public class ReserveDAOImpl implements ReserveDAO {
	
	@Autowired
	private SqlSession session;
	
	@Override
	public int reservePublic(ReserveVO rvo) {
		// TODO Auto-generated method stub
		return session.insert("reservePublic", rvo);
	}
	
	@Override
	public int reserveNumSeq() {
		return (int)session.selectOne("reserveNumSeq");
	}

}
