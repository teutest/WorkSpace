package com.workspace.client.reserve.vo;

import java.util.List;

public class ReserveListVO {
	
	private List<ReserveVO> reserveList;

	public List<ReserveVO> getReserveList() {
		return reserveList;
	}

	public void setReserveList(List<ReserveVO> reserveList) {
		this.reserveList = reserveList;
	}

}
