package com.workspace.client.reserve.dao;

import com.workspace.client.reserve.vo.ReserveVO;

public interface ReserveDAO {
	public int reservePublic(ReserveVO rvo);
	public int reserveNumSeq();
}
