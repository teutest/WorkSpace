package com.workspace.client.reserve.service;

import com.workspace.client.reserve.vo.ReserveVO;

public interface ReserveService {
	public int reservePublic(ReserveVO rvo);
}
