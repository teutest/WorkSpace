package com.workspace.client.reserve.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.workspace.client.reserve.dao.ReserveDAO;
import com.workspace.client.reserve.vo.ReserveVO;

@Service
@Transactional
public class ReserveServiceImpl implements ReserveService {
	
	@Autowired
	private ReserveDAO reserveDAO;
	
	@Override
	public int reservePublic(ReserveVO rvo) {
		try {
			rvo.setReserve_num(reserveDAO.reserveNumSeq());
			reserveDAO.reservePublic(rvo);
			return 1;
		}catch(RuntimeException e) {
			e.printStackTrace();
			return 2;
		}
		
	}

}
