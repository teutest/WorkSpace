package com.workspace.client.reserve.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.workspace.client.reserve.service.ReserveService;
import com.workspace.client.reserve.vo.ReserveVO;

@Controller
@RequestMapping(value="/reserve")
public class ReserveController {
	
	@Autowired
	private ReserveService reserveService;
	
	/* 예약하기 */
	@RequestMapping(value="/booking", method = RequestMethod.POST)
	public String reservePublic(@RequestParam("use_date") String use_date,
								@RequestParam("hours") String hours,
								@RequestParam("s_price") String total_cost,
								@RequestParam("s_name") String s_name,
								@RequestParam("u_id") String u_id, ReserveVO rvo,
								Model model) {
		
		System.out.println("파람 공간이름 :" + s_name);
		
		rvo.setUse_date(use_date);
		rvo.setHours(hours);
		rvo.setTotal_cost(Integer.parseInt(total_cost));
		rvo.setS_name(s_name);
		rvo.setU_id(u_id);
		
		if (reserveService.reservePublic(rvo) == 1) {
			model.addAttribute("msg", "공용공간 예약 신청이 완료됐습니다.");
			model.addAttribute("msg2", "대여료는 결제수단관리 메뉴에서 설정된 수단으로 결제됩니다. ");
			model.addAttribute("url", "/space/SpacePublicList");
		} else {
			model.addAttribute("msg", "공용공간 예약 신청에 실패했습니다. 잠시 후 다시 시도해주세요.");
			model.addAttribute("url", "/space/SpacePublicList");
		}
		
		return "redirect";
	}
}
