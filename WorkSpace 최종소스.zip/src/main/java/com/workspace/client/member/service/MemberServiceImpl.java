package com.workspace.client.member.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.workspace.client.common.util.OpenCrypt;
import com.workspace.client.common.util.Util;
import com.workspace.client.member.dao.MemberDAO;
import com.workspace.client.member.vo.MemberSecurity;
import com.workspace.client.member.vo.MemberVO;
import com.workspace.client.reserve.vo.ReserveVO;

@Service
@Transactional
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MemberDAO memberDao;
		
	// 아이디 중복검사
	@Override
	public int u_idConfirm(String u_id) {
		if (memberDao.memberSelect(u_id) != null) {
			// 아이디 중복
			return 1;
		} else {
			// 아이디 중복 아님
			return 2;
		}
	}
	
	// 사업자등록번호 중복검사
	@Override
	public int comp_numConfirm(String comp_num) {
		System.out.println("사업자등록번호 중복검사 서비스");
		if (memberDao.memberSelectByCompNum(comp_num) != null) {
			// 사업자등록번호 중복
			return 1;
		} else {
			// 사업자등록번호 중복 아님
			return 2;
		}
	}
	
	// 내정보 중 비밀번호 수정
	@Override
	public void updatePw(MemberVO vo) {

		memberDao.updatePw(vo);

	}
	// 비밀번호 확인 구현
	@Override
	public int pwdConfirm(MemberVO mvo) {
		int result = 0;
		result = memberDao.pwdConfirm(mvo);
		return result;
	}
	
	// 회원가입(입주신청) 처리
	public int memberInsert(MemberVO mvo) {
		System.out.println("회원가입(입주신청) 처리 서비스");
		
		int sCode = 2;		
				
		if (!(memberDao.s_stateSelect(mvo.getS_name()).equals("사용가능"))) {
			return 1; // 입주신청 실패(공간 사용가능 상태 아님)
		} else if (memberDao.memberSelect(mvo.getU_id()) != null){
			return 2; // 입주신청 실패(아이디 중복)
		} else if (memberDao.memberSelectByCompNum(mvo.getComp_num()) != null) {
			return 3; // 입주신청 실패(사업자등록번호 중복)
		} else {
			try {
				MemberSecurity sec = new MemberSecurity();
				sec.setU_id(mvo.getU_id());
				sec.setSalt(Util.getRandomString());
				sCode = memberDao.securityInsert(sec);
				
				if (sCode == 1) {
					// 비밀번호 암호화 테이블 insert 성공 시
					mvo.setU_pw(new String(OpenCrypt.getSHA256(mvo.getU_pw(), sec.getSalt())));
					if (memberDao.memberInsert(mvo) == 1) {
						if (memberDao.s_stateInUse(mvo.getS_name()) == 1) {
							return 5; // 입주신청 성공
						} else {
							return 4; // 입주신청 실패(공간 사용현황 변경 실패)
						}
					} else {
						return 4; // 입주신청 실패(멤버 insert 실패)
					}
				} else {
					return 4; // 입주신청 실패(비밀번호 암호화 실패)
				}
			} catch (Exception e) {
				e.printStackTrace();
				TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
				return 4; // 입주신청 실패(예외 발생)
			}
		}
	}
	
	// 내정보 보기
	@Override
	public MemberVO readMember(String u_id) {
		System.out.println("readMember()실행");
		MemberVO vo = null;
		try {
			vo = memberDao.readMember(u_id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return vo;
	}

	// 내정보 수정하기
	@Override
	public void updateMember(MemberVO vo) {
		try {
			memberDao.updateMember(vo);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// salt 값 조회
	@Override
	public MemberSecurity findSalt(String u_id) {
		MemberSecurity sec = null;

		sec = memberDao.findSalt(u_id);

		return sec;
	}

	// 입주정보 조회하기
	@Override
	public MemberVO readContractInfo(String u_id) {
		System.out.println("입주정보 조회하기 Service");
		MemberVO vo = null;
		try {
			vo = memberDao.readContractInfo(u_id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return vo;
	}

	// 입주정보_취소신청
	@Override
	public int updateCancelApply(MemberVO mvo) {
		System.out.println("취소신청 Service");
		int result = memberDao.updateCancelApply(mvo);

		return result;
	}

	// 입주정보_갱신신청
	@Override
	public int updateRenewalApply(MemberVO mvo) {
		System.out.println("갱신신청 Service");
		int result = memberDao.updateRenewalApply(mvo);

		return result;
	}

	// 공용공간 예약정보 조회하기
	@Override
	public List<ReserveVO> readReserveInfo(String u_id) {
		System.out.println("공용공간 예약정보 조회하기 Service 실행");
		List<ReserveVO> reserveList = null;
		try {
			reserveList = memberDao.readReserveInfo(u_id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return reserveList;
	}

	// 공용공간_취소신청
	@Override
	public int updateCancelReserve(ReserveVO rvo) {
		System.out.println("공용공간 예약취소 신청 Service 작동");
		int result = memberDao.updateCancelReserve(rvo);

		return result;
	}

	// 결제수단 관리
	@Override
	public int updatePayment(MemberVO mvo) {
		int result = memberDao.updatePayment(mvo);

		return result;
	}
}
