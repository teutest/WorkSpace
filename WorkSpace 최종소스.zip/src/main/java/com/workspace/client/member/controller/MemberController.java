package com.workspace.client.member.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.workspace.client.common.util.OpenCrypt;
import com.workspace.client.login.service.LoginService;
import com.workspace.client.login.vo.LoginVO;
import com.workspace.client.member.service.MemberService;
import com.workspace.client.member.vo.MemberSecurity;
import com.workspace.client.member.vo.MemberVO;
import com.workspace.client.reserve.vo.ReserveVO;

@Controller
@RequestMapping(value = "/member")
public class MemberController {

	@Autowired
	private MemberService memberService;
	
	@Autowired
	private LoginService loginService;
	
	// 사무공간 상세페이지에서 입주신청 클릭 시 약관동의1 페이지로 이동
	@RequestMapping(value = "/agreement1", method = RequestMethod.GET)
	public String agreement1(@RequestParam("s_name") String s_name,
							 @RequestParam("s_price") String s_price,
							 HttpServletRequest request,
							 Model model) {
		System.out.println("이용약관1 컨트롤러");
		
		model.addAttribute("s_name", s_name);
		model.addAttribute("s_price", s_price);
		
		return "member/agreement1";
	}
	
	// 약관동의1 페이지에서 모두 동의 시 약관동의2 페이지로 이동
	@RequestMapping(value = "/agreement2", method = RequestMethod.POST)
	public String agreement2(@RequestParam("s_name") String s_name,
			 				 @RequestParam("s_price") String s_price,
			 				 @RequestParam("agree_info") String agree_info,
			 				 Model model) {
		System.out.println("이용약관2 컨트롤러");
		
		model.addAttribute("s_name", s_name);
		model.addAttribute("s_price", s_price);
		model.addAttribute("agree_info", agree_info);
		
		return "member/agreement2";
	}

	// 약관동의2 페이지에서 모두 동의 시 입주신청 페이지로 이동
	@RequestMapping(value = "/joinForm", method = RequestMethod.POST)
	public String joinForm(@RequestParam("s_name") String s_name,
						   @RequestParam("s_price") String s_price,
						   @RequestParam("agree_info") String agree_info,
						   @RequestParam("agree_pricePolicy") String agree_pricePolicy,
						   @RequestParam("agree_contRenewal") String agree_contRenewal,
						   @RequestParam("agree_contWithdrawal") String agree_contWithdrawal,
						   Model model) {
		System.out.println("joinForm 컨트롤러");
		
		model.addAttribute("s_price", s_price);
		model.addAttribute("s_name", s_name);
		model.addAttribute("agree_info", agree_info);
		model.addAttribute("agree_pricePolicy", agree_pricePolicy);
		model.addAttribute("agree_contRenewal", agree_contRenewal);
		model.addAttribute("agree_contWithdrawal", agree_contWithdrawal);
		
		return "member/joinForm";
	}
	
	// 사용자 아이디 중복 체크
	@ResponseBody
	@RequestMapping(value = "/u_idConfirm", method = RequestMethod.POST)
	public String u_idConfirm(@RequestParam("u_id") String u_id) {
		System.out.println("아이디 중복검사 컨트롤러");
		
		int result = memberService.u_idConfirm(u_id);
		return result + "";
	}
	
	// 사업자등록번호 중복 체크
	@ResponseBody
	@RequestMapping(value = "/comp_numConfirm", method = RequestMethod.POST)
	public String comp_numConfirm(@RequestParam("comp_num") String comp_num) {
		System.out.println("사업자등록번호 중복검사 컨트롤러");
		
		int result = memberService.comp_numConfirm(comp_num);
		return result + "";
	}	
	
	// 회원가입(입주신청) 처리
	@RequestMapping(value = "/join", method = RequestMethod.POST)
	public String memberInsert(@RequestParam("u_id") String u_id,
							   @RequestParam("u_pw") String u_pw,
							   @RequestParam("comp_name") String comp_name,
							   @RequestParam("comp_num") String comp_num,
							   @RequestParam("u_num") String u_num,
							   @RequestParam("u_name") String u_name,
							   @RequestParam("u_phoneNum") String u_phoneNum,
							   @RequestParam("u_email") String u_email,
							   @RequestParam("start_date") String start_date,
							   @RequestParam("initial_contMonth") String initial_contMonth,
							   @RequestParam("agree_info") String agree_info,
							   @RequestParam("agree_pricePolicy") String agree_pricePolicy,
							   @RequestParam("agree_contRenewal") String agree_contRenewal,
							   @RequestParam("agree_contWithdrawal") String agree_contWithdrawal,
							   @RequestParam("s_name") String s_name,
							   @RequestParam("s_price") String s_price,
							   Model model) throws ParseException {
		
		System.out.println("회원가입(입주신청) 처리 컨트롤러");

		// MemberVO 인스턴스 생성 및 필드값 설정
		MemberVO mvo = new MemberVO();
		mvo.setU_id(u_id);
		mvo.setU_pw(u_pw);
		mvo.setComp_name(comp_name);
		mvo.setComp_num(comp_num);
		mvo.setU_num(Integer.parseInt(u_num));
		mvo.setU_name(u_name);
		mvo.setU_phoneNum(u_phoneNum);
		mvo.setU_email(u_email);
		mvo.setAgree_info(agree_info);
		mvo.setAgree_pricePolicy(agree_pricePolicy);
		mvo.setAgree_contRenewal(agree_contRenewal);
		mvo.setAgree_contWithdrawal(agree_contWithdrawal);
		mvo.setS_name(s_name);
		mvo.setCont_state("승인대기");
		mvo.setStart_date(start_date);
		mvo.setInitial_contMonth(Integer.parseInt(initial_contMonth));
		mvo.setTotal_contMonth(Integer.parseInt(initial_contMonth));
		
		// 계약 만료일 구하고 MemberVO 인스턴스 end_date 값 설정
		SimpleDateFormat fm = new SimpleDateFormat("yyyy-MM-dd");
		Date fm_start_date = fm.parse(start_date); // 문자열인 start_date와 같은 날짜를 갖는 Date 타입의 fm_start_date 생성
		Calendar cal = Calendar.getInstance(); // 날짜 덧셈을 위한 Calendar 인스턴스 생성
		cal.setTime(fm_start_date); // fm_start_date를 Calendar 인스턴스에 설정
		cal.add(Calendar.MONTH, Integer.parseInt(initial_contMonth)); // 초기 계약 개월 수 더하기
		String end_date = fm.format(cal.getTime()); // 계산된 날짜를 지정한 포맷의 문자열로 변환하여 end_date 변수에 대입
		mvo.setEnd_date(end_date);
		
		// 총 계약금액 구하고 MemberVO 인스턴스 total_cost 값 설정
		int total_cost = (Integer.parseInt(s_price)) * (Integer.parseInt(initial_contMonth));
		mvo.setTotal_cost(total_cost);
		
		
		// insert 시작 ===============================================================
		
		int result = 0;
		String url = "";
		
		result = memberService.memberInsert(mvo);
		
		switch (result) {
		case 1:
			model.addAttribute("msg", "사용이 불가능한 공간입니다. 다른 사무공간을 신청해주세요.");
			model.addAttribute("url", "/space/spacePrivateList");
			url = "redirect";
			break;
		case 2:
			model.addAttribute("errCode", 2); // 아이디 중복
			url = "member/joinForm"; // 입주신청(회원가입) 정보 입력창으로 이동
			break;
		case 3:
			model.addAttribute("errCode", 3); // 사업자등록번호 중복
			url = "member/joinForm"; // 입주신청(회원가입) 정보 입력창으로 이동
			break;
		case 4:
			model.addAttribute("errCode", 4); // DB 예외 발생
			url = "member/joinForm"; // 입주신청(회원가입) 정보 입력창으로 이동
			break;
		case 5:
			model.addAttribute("msg", "입주신청이 완료됐습니다. 상담 매니저가 1일 내에 연락 드리겠습니다.");
			model.addAttribute("url", "/");
			url = "redirect";
			break;
		}
		
		return url;
	}
	
	/*******************************************************
	 * 내정보 조회하기
	 *******************************************************/
	@RequestMapping(value = "/info/memberUserInfo", method = RequestMethod.GET)
	public void infoGET(HttpSession session, Model model) throws Exception {
		// 세션객체 안에있는 ID정보 저장
		String u_id = (String) session.getAttribute("u_id");

		System.out.println(u_id);

		// 서비스안의 내정보 조회하기 메서드 호출
		MemberVO vo = new MemberVO();
		vo = memberService.readMember(u_id);

		// 정보저장후 페이지 이동
		model.addAttribute("memVO", vo);
	}

	/******************************************************
	 * 내정보 수정하기
	 ****************************************************/

	@RequestMapping(value = "/memberModify", method = RequestMethod.POST)
	public String updateGET(HttpSession session, Model model) throws Exception {

		String u_id = (String) session.getAttribute("u_id");

		MemberVO vo = new MemberVO();
		vo = memberService.readMember(u_id);

		model.addAttribute("memVo", vo);

		return "member/memberModify";
	}

	@RequestMapping(value = "/memberUpdate" ,  method=RequestMethod.POST)
	public String updatePOST(@ModelAttribute MemberVO vo) throws Exception {
		
		MemberVO mvo = new MemberVO();
		
		mvo = memberService.readMember(vo.getU_id());
		
		if (mvo.getU_pw().equals(vo.getU_pw())) { // 비밀번호 제외한 정보 수정
			
			memberService.updateMember(vo);
			
			System.out.println("비밀번호 제외 변경 성공");
			
		} else { //비밀번호를 수정했을경우 
			MemberSecurity sec = memberService.findSalt(vo.getU_id());
			
			vo.setU_pw(new String(OpenCrypt.getSHA256(vo.getU_pw(), sec.getSalt())));
			
			memberService.updateMember(vo);
			// 비밀번호 수정
			memberService.updatePw(vo);
			
			System.out.println("비밀번호 포함 변경 성공");
		}
	
		return "redirect:/member/info/memberUserInfo";
	}
	
	/******************************************************
	 * 비밀번호 확인
	 ****************************************************/
	@ResponseBody
	@RequestMapping(value="/pwdConfirm", method=RequestMethod.POST, produces = "text/plain; charset=UTF-8")
	public String pwdConfirm(@ModelAttribute MemberVO mvo,
							 @RequestParam("b_pwd") String b_pwd) {
		
		// DB 회원 테이블에 있는 ID로 DB Security 테이블에 있는 솔트값을 가져옴
		MemberSecurity sec = memberService.findSalt(mvo.getU_id());
		
		LoginVO login = new LoginVO();
		login.setU_id(mvo.getU_id());
		
		LoginVO realLoginValue = loginService.login(login);
		
		MemberVO vo = new MemberVO();
		// 새로운 VO 객체에 DB Security 테이블에 있는 솔트값과 내정보에서 수정하기 위해 입력한 PW를 암호화해서 넣고, ID도 넣음
		vo.setU_pw(new String(OpenCrypt.getSHA256(b_pwd, sec.getSalt())));
		
		String value = "";
		
		if (realLoginValue.getU_pw().equals(vo.getU_pw())) {
			System.out.println("b_pwd 암호화 :" + vo.getU_pw());
			System.out.println("DB에 있는 PW) : " + mvo.getU_pw());
			System.out.println("내정보에서 수정하기위해 입력한 PW : " + b_pwd);
			value = "성공";
		} else { // 로그인 실패 시
			value="실패";
		}
		
		//int result = memberService.pwdConfirm(vo);
		
		return value + "";
	}
	
	/*********************************************************
	 * 입주정보 리스트 출력
	 *********************************************************/
	@RequestMapping(value = "/info/memberContractInfo", method = RequestMethod.GET)
	public void contractInfo(HttpSession session, Model model) {
		System.out.println("입주정보 리스트 출력 컨트롤러");
		
		// 세션객체 안에있는 ID정보 저장
		String u_id = (String) session.getAttribute("u_id");

		//서비스안의 입주정보조회 메소드 호출
		MemberVO vo = new MemberVO();
		vo = memberService.readContractInfo(u_id);
		
		//정보저장후 페이지 이동 
		model.addAttribute("memVO", vo);
	}
	
	/*******************************************************
	 * 갱신신청버튼 클릭 시
	 *******************************************************/
	@ResponseBody
	@RequestMapping(value="/info/renewalApply",method = RequestMethod.POST)
	public int renewalApply(@RequestParam("renewal_months")  String renewal_months ,Model model, HttpSession session) {
		String u_id = (String)session.getAttribute("u_id");
		
		System.out.println("갱신신청 Controller");
		
		MemberVO mvo = new MemberVO();
		
		//MemberVO에 갱신신청값과 ID를 저장
		if(renewal_months.equals("1개월")) {
			mvo.setRenewal_months(1);
		}else if(renewal_months.equals("3개월")) {
			mvo.setRenewal_months(3);
		}else if(renewal_months.equals("6개월")) {
			mvo.setRenewal_months(6);
		}else if(renewal_months.equals("1년")) {
			mvo.setRenewal_months(12);
		}
		mvo.setU_id(u_id);
		mvo.setR_apply("Y");
		mvo.setR_state("갱신승인대기");
		
		int result = memberService.updateRenewalApply(mvo);
		
		model.addAttribute("renewal_months", mvo.getRenewal_months());
		
		return result;
	}
	
	/*******************************************************
	 * 취소신청버튼 클릭 시 
	 *******************************************************/
	@ResponseBody
	@RequestMapping(value="/info/cancelApply", method = RequestMethod.POST)
	public int cancelApply(@RequestParam("w_apply")String w_apply, Model model, HttpSession session) {
		String u_id = (String)session.getAttribute("u_id");
		
		System.out.println("취소신청 Controller");
		
		MemberVO mvo = new MemberVO();
		
		//MemberVO에 취소신청값과 id를 저장 
		mvo.setW_apply(w_apply);
		mvo.setU_id(u_id);
		
		int result = memberService.updateCancelApply(mvo);
		
		model.addAttribute("w_apply", mvo.getW_apply());
		
		return result;
	}
	
	/*******************************************************
	 *공용공간 예약정보 조회
	 *******************************************************/
	
	@RequestMapping(value = "/info/memberReserveInfo" , method = RequestMethod.GET)
	public String reserveInfo(HttpSession session , Model model ) {
		System.out.println("공용공간 예약정보 출력 Controller 실행");
		
		//세션객체 안에있는 ID정보 저장
		String u_id = (String)session.getAttribute("u_id");
		
		//서비스안의 공용공간예약정보 조회 메소드 호출 
		List<ReserveVO> reserveList = memberService.readReserveInfo(u_id);	
		
		// 결제수단 등록여부 조회
		MemberVO mvo = memberService.readMember(u_id);
		
		String payment = mvo.getPayment();
		
		//정보저장후 페이지 이동
		model.addAttribute("reserveList", reserveList);
		model.addAttribute("payment", payment);
		
		return "member/info/memberReserveInfo";
	}
	
	/*******************************************************
	 *공용공간 예약취소
	 *******************************************************/
	@ResponseBody
	@RequestMapping(value="/info/cancelReserve" , method = RequestMethod.POST)
	public int cancelReserve(@RequestParam("reserve_num")int reserve_num,Model model,HttpSession session) {
		String u_id = (String)session.getAttribute("u_id");
		
		System.out.println("공용공간 예약취소신청 Controller 작동");
		
		ReserveVO rvo = new ReserveVO();
		
		//ReserveVO에 취소신청의 값과 id를 저장
		rvo.setReserve_num(reserve_num);
		rvo.setU_id(u_id);
		
		int result = memberService.updateCancelReserve(rvo);
		
		model.addAttribute("reserve_num", rvo.getReserve_num());
		
		return result;
		
	}
	
	// 결제수단관리 페이지 보이기
	@RequestMapping(value = "/info/memberPaymentInfo", method = RequestMethod.GET)
	public String paymentPage(HttpSession session,Model model) {

		String u_id = (String) session.getAttribute("u_id");
		
		MemberVO mvo = new MemberVO();
		
		// 아이디로 회원의 결제수단 등록여부 조회
		mvo = memberService.readMember(u_id);
		
		System.out.println("db 등록 결제수단 : " + mvo.getPayment());

		model.addAttribute("payment", mvo.getPayment());

		return "member/info/memberPaymentInfo";

	}

	// 결제수단 관리 
	@ResponseBody
	@RequestMapping(value = "/info/memberPaymentInfo", method = RequestMethod.POST)
	public int paymentInfo(@RequestParam("payment") String payment, Model model, HttpSession session) {

		String u_id = (String) session.getAttribute("u_id");
		
		System.out.println("선택한 결제수단 : " + payment);

		MemberVO mvo = new MemberVO();
		
		// MemberVO에 선택한 결제수단과 id를 저장
		mvo.setPayment(payment);
		mvo.setU_id(u_id);
		
		int result = memberService.updatePayment(mvo);
		
		model.addAttribute("payment", mvo.getPayment());
			
		return result;
	}
}