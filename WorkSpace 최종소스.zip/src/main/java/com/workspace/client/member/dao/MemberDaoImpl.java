package com.workspace.client.member.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.workspace.client.member.vo.MemberSecurity;
import com.workspace.client.member.vo.MemberVO;
import com.workspace.client.reserve.vo.ReserveVO;

@Repository
public class MemberDaoImpl implements MemberDAO {
	
	@Autowired
	private SqlSession session;
	
	// ID로 멤버 조회
	@Override
	public MemberVO memberSelect(String u_id) {
		System.out.println("ID로 멤버 조회 DAO");
		return session.selectOne("memberSelect", u_id);
	}
	
	// 사업자등록번호로 멤버 조회
	@Override
	public MemberVO memberSelectByCompNum(String comp_num) {
		System.out.println("사업자등록번호로 멤버 조회 DAO");
		return session.selectOne("memberSelectByCompNum", comp_num);
	}
	
	// 공간명으로 사용현황 조회
	@Override
	public String s_stateSelect(String s_name) {
		System.out.println("공간명으로 사용현황 조회 DAO");
		return session.selectOne("s_stateSelect", s_name);
	}
	
	// 비밀번호 암호화 테이블 insert
	@Override
	public int securityInsert(MemberSecurity set) {
		System.out.println("비밀번호 암호화 테이블 insert DAO");
		return session.insert("securityInsert", set);
	}
	
	// 멤버 insert
	@Override
	public int memberInsert(MemberVO mvo) {
		System.out.println("멤버 insert DAO");
		return session.insert("memberInsert", mvo);
	}
	
	// 공간 사용현황 사용중으로 변경
	@Override
	public int s_stateInUse(String s_name) {
		System.out.println("공간 사용현황 사용중으로 변경 DAO");
		return session.update("s_stateInUse", s_name);
	}
	
	// 내정보 조회하기
	@Override
	public MemberVO readMember(String u_id) throws Exception {
		// 테스트(컨트롤러)호출 -> 정보를 저장 -> DB로이동
		MemberVO vo = session.selectOne("readMember", u_id);
		return vo;
	}

	// 내정보 수정하기(정보를 가지고 mapper로 이동)
	@Override
	public void updateMember(MemberVO vo) throws Exception {
		session.update("updateMember", vo);
	}

	// 내정보 중 비밀번호 수정하기
	public int updatePw(MemberVO vo) {
		return session.update("com.workspace.client.member.dao.MemberDAO.updatePw", vo);
	}

	// salt 값 조회
	@Override
	public MemberSecurity findSalt(String u_id) {

		return session.selectOne("findSalt", u_id);
	}

	// 비밀번호 확인 구현
	@Override
	public int pwdConfirm(MemberVO mvo) {
		return (Integer) session.selectOne("pwdConfirm", mvo);
	}

	// 입주정보 조회하기
	@Override
	public MemberVO readContractInfo(String u_id) throws Exception {
		System.out.println("입주정보 DAO");
		MemberVO vo = session.selectOne("readContractInfo", u_id);
		return vo;
	}

	// 입주정보_취소신청
	@Override
	public int updateCancelApply(MemberVO mvo) {
		System.out.println("취소신청 DAO");
		return session.update("updateCancelApply", mvo);
	}

	// 입주정보_갱신신청
	@Override
	public int updateRenewalApply(MemberVO mvo) {
		System.out.println("갱신신청 DAO");
		return session.update("updateRenewalApply", mvo);
	}

	// 공용공간 예약정보 조회하기
	@Override
	public List<ReserveVO> readReserveInfo(String u_id) throws Exception {
		System.out.println("공용공간 예약정보 DAO 실행");
		List<ReserveVO> reserveList = session.selectList("readReserveInfo", u_id);
		return reserveList;
	}

	// 공용공간_취소신청
	@Override
	public int updateCancelReserve(ReserveVO rvo) {
		System.out.println("공용공간 예약취소 신청 DAO 작동");
		return session.update("updateCancelReserve", rvo);
	}
	
	// 결제수단관리
	@Override
	public int updatePayment(MemberVO mvo) {

		return session.update("updatePayment", mvo);
	}

}
