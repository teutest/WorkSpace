package com.workspace.client.member.service;

import java.util.List;

import com.workspace.client.member.vo.MemberSecurity;
import com.workspace.client.member.vo.MemberVO;
import com.workspace.client.reserve.vo.ReserveVO;

public interface MemberService {
	
	// 아이디 중복검사
	public int u_idConfirm(String u_id);
	
	// 사업자등록번호 중복검사
	public int comp_numConfirm(String comp_num);
	
	// 회원가입(입주신청) 처리
	public int memberInsert(MemberVO mvo);
	
	// 내 정보 보기
	public MemberVO readMember(String u_id);

	// 내정보 수정하기
	public void updateMember(MemberVO vo);

	// salt 값 조회
	public MemberSecurity findSalt(String u_id);

	// 비밀번호 확인
	public int pwdConfirm(MemberVO mvo);

	// 내정보 중 비밀번호 수정
	public void updatePw(MemberVO vo);

	// 입주정보 조회하기
	public MemberVO readContractInfo(String u_id);

	// 입주정보_취소신청
	public int updateCancelApply(MemberVO mvo);

	// 입주정보_갱신신청
	public int updateRenewalApply(MemberVO mvo);

	// 공용공간 예약정보 조회
	public List<ReserveVO> readReserveInfo(String u_id);

	// 공용공간_취소신청
	public int updateCancelReserve(ReserveVO rvo);
	
	// 결제수단관리
	public int updatePayment(MemberVO mvo);

}
