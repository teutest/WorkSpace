package com.workspace.client.member.dao;

import java.util.List;

import com.workspace.client.member.vo.MemberSecurity;
import com.workspace.client.member.vo.MemberVO;
import com.workspace.client.reserve.vo.ReserveVO;

public interface MemberDAO {
	
	// ID로 멤버 조회 
	public MemberVO memberSelect(String u_id);
	
	// 사업자등록번호로 멤버 조회 
	public MemberVO memberSelectByCompNum(String comp_num);
	
	// 공간명으로 사용현황 조회
	public String s_stateSelect(String s_name);
	
	// 비밀번호 암호화 테이블 insert
	public int securityInsert(MemberSecurity set);
		
	// 멤버 insert
	public int memberInsert(MemberVO mvo);
	
	// 공간 사용현황 사용중으로 변경
	public int s_stateInUse(String s_name);
	
	// 내정보 조회하기
	public MemberVO readMember(String u_id) throws Exception;

	// 내정보 수정하기
	public void updateMember(MemberVO vo) throws Exception;

	// 내정보 중 비밀번호 수정하기
	public int updatePw(MemberVO vo);

	// salt 값 조회
	public MemberSecurity findSalt(String u_id);

	// 비밀번호 확인
	public int pwdConfirm(MemberVO mvo);

	// 입주정보 조회하기
	public MemberVO readContractInfo(String u_id) throws Exception;

	// 입주정보_취소신청
	public int updateCancelApply(MemberVO mvo);

	// 입주정보_갱신신청
	public int updateRenewalApply(MemberVO mvo);

	// 공용공간 예약정보 조회하기
	public List<ReserveVO> readReserveInfo(String u_id) throws Exception;

	// 공용공간_취소신청
	public int updateCancelReserve(ReserveVO rvo);
	
	// 결제수단관리
	public int updatePayment(MemberVO mvo);
}
