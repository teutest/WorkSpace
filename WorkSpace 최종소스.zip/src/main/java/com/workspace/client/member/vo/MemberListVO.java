package com.workspace.client.member.vo;

import java.util.List;

public class MemberListVO {

	private List<MemberVO> memberList;

	public List<MemberVO> getMemberList() {
		return memberList;
	}

	public void setMemberList(List<MemberVO> memberList) {
		this.memberList = memberList;
	}

}
