package com.workspace.client.member.vo;

import com.workspace.client.common.vo.CommonVO;

public class MemberVO extends CommonVO {

	private String u_id;
	private String u_pw;
	private String comp_name;
	private String comp_num;
	private int u_num;
	private String u_name;
	private String u_phoneNum;
	private String u_email;
	private String agree_info;
	private String agree_pricePolicy;
	private String agree_contRenewal;
	private String agree_contWithdrawal;
	private String s_name;
	private String cont_state;
	private String start_date;
	private String end_date;
	private int initial_contMonth;
	private int total_contMonth;
	private int total_cost;
	private String payment;
	private int renewal_months;
	private String r_apply;
	private String r_state;
	private String w_apply;
	private String w_state;
	private String deactivated;
	
	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	public String getU_pw() {
		return u_pw;
	}
	public void setU_pw(String u_pw) {
		this.u_pw = u_pw;
	}
	public String getComp_name() {
		return comp_name;
	}
	public void setComp_name(String comp_name) {
		this.comp_name = comp_name;
	}
	public String getComp_num() {
		return comp_num;
	}
	public void setComp_num(String comp_num) {
		this.comp_num = comp_num;
	}
	public int getU_num() {
		return u_num;
	}
	public void setU_num(int u_num) {
		this.u_num = u_num;
	}
	public String getU_name() {
		return u_name;
	}
	public void setU_name(String u_name) {
		this.u_name = u_name;
	}
	public String getU_phoneNum() {
		return u_phoneNum;
	}
	public void setU_phoneNum(String u_phoneNum) {
		this.u_phoneNum = u_phoneNum;
	}
	public String getU_email() {
		return u_email;
	}
	public void setU_email(String u_email) {
		this.u_email = u_email;
	}
	public String getAgree_info() {
		return agree_info;
	}
	public void setAgree_info(String agree_info) {
		this.agree_info = agree_info;
	}
	public String getAgree_pricePolicy() {
		return agree_pricePolicy;
	}
	public void setAgree_pricePolicy(String agree_pricePolicy) {
		this.agree_pricePolicy = agree_pricePolicy;
	}
	public String getAgree_contRenewal() {
		return agree_contRenewal;
	}
	public void setAgree_contRenewal(String agree_contRenewal) {
		this.agree_contRenewal = agree_contRenewal;
	}
	public String getAgree_contWithdrawal() {
		return agree_contWithdrawal;
	}
	public void setAgree_contWithdrawal(String agree_contWithdrawal) {
		this.agree_contWithdrawal = agree_contWithdrawal;
	}
	public String getS_name() {
		return s_name;
	}
	public void setS_name(String s_name) {
		this.s_name = s_name;
	}
	public String getCont_state() {
		return cont_state;
	}
	public void setCont_state(String cont_state) {
		this.cont_state = cont_state;
	}
	public String getStart_date() {
		return start_date;
	}
	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}
	public String getEnd_date() {
		return end_date;
	}
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	public int getInitial_contMonth() {
		return initial_contMonth;
	}
	public void setInitial_contMonth(int initial_contMonth) {
		this.initial_contMonth = initial_contMonth;
	}
	public int getTotal_contMonth() {
		return total_contMonth;
	}
	public void setTotal_contMonth(int total_contMonth) {
		this.total_contMonth = total_contMonth;
	}
	public int getTotal_cost() {
		return total_cost;
	}
	public void setTotal_cost(int total_cost) {
		this.total_cost = total_cost;
	}
	public String getPayment() {
		return payment;
	}
	public void setPayment(String payment) {
		this.payment = payment;
	}
	public int getRenewal_months() {
		return renewal_months;
	}
	public void setRenewal_months(int renewal_months) {
		this.renewal_months = renewal_months;
	}
	public String getR_apply() {
		return r_apply;
	}
	public void setR_apply(String r_apply) {
		this.r_apply = r_apply;
	}
	public String getR_state() {
		return r_state;
	}
	public void setR_state(String r_state) {
		this.r_state = r_state;
	}
	public String getW_apply() {
		return w_apply;
	}
	public void setW_apply(String w_apply) {
		this.w_apply = w_apply;
	}
	public String getW_state() {
		return w_state;
	}
	public void setW_state(String w_state) {
		this.w_state = w_state;
	}
	public String getDeactivated() {
		return deactivated;
	}
	public void setDeactivated(String deactivated) {
		this.deactivated = deactivated;
	}
	
}
