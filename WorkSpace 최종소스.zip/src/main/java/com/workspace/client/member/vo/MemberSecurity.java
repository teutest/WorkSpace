package com.workspace.client.member.vo;

public class MemberSecurity {
	//필드
	private String u_id; 
	private String salt;
	
	//생성자
	public MemberSecurity() {
		super();
	}
	public MemberSecurity(String u_id, String salt) {
		super();
		this.u_id = u_id;
		this.salt = salt;
	}
	
	//게터 세터
	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	public String getSalt() {
		return salt;
	}
	public void setSalt(String salt) {
		this.salt = salt;
	}
	
	
	
	
}
