package com.workspace.admin.reserve.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.workspace.admin.reserve.dao.AdminReserveDAO;
import com.workspace.client.reserve.vo.ReserveVO;

@Service
@Transactional
public class AdminReserveServiceImpl implements AdminReserveService {

	@Autowired
	private AdminReserveDAO adminReserveDAO;
	
	@Override
	// 공용공간 예약 리스트 출력
	public Map<String, Object> reserveList(Map<String, Integer> pagingMap) {
		Map<String, Object> reserveListMap = new HashMap<String, Object>();
		
		// 공용공간 예약 리스트 출력
		List<ReserveVO> reserveList = adminReserveDAO.reserveList(pagingMap);
		
		// 전체 공용공간 예약 리스트 수 조회
		int totReserveList = adminReserveDAO.totReserveList();
		
		reserveListMap.put("reserveList", reserveList);
		reserveListMap.put("totReserveList", totReserveList);
		
		return reserveListMap;
	}
	
	@Override
	// 공용공간 예약 리스트 출력(카테고리 선택값, 회사명 입력값으로 조회)
	public Map<String, Object> reserveListSearch(Map<String, Object> pagingMap) {
		Map<String, Object> reserveListMap = new HashMap<String, Object>();
		
		// 공용공간 예약 리스트 출력
		List<ReserveVO> reserveList = adminReserveDAO.reserveListSearch(pagingMap);
		
		// 카테고리, 키워드 조건에 맞는 공용공간 예약 리스트 수 조회
		int reserveListCnt = adminReserveDAO.reserveListCnt(pagingMap);
		
		reserveListMap.put("reserveList", reserveList);
		reserveListMap.put("reserveListCnt", reserveListCnt);
		
		return reserveListMap;
	}
	
	@Override
	// 공용공간 예약 수정 - 예약완료
	public int reserveApproval(ReserveVO rvo) {
		return adminReserveDAO.reserveApproval(rvo);
	}
	
	@Override
	// 공용공간 예약 수정 - 예약취소(예약 강제 취소) 및 이용시간 리셋
	public int reserveDisapproval(ReserveVO rvo) {
		return adminReserveDAO.reserveDisapproval(rvo);
	}
	
	@Override
	// 공용공간 예약 수정 - 취소승인(고객의 취소 요청)
	public int reserveWithdrawalApproval(ReserveVO rvo) {
		return adminReserveDAO.reserveWithdrawalApproval(rvo);
	}
}
