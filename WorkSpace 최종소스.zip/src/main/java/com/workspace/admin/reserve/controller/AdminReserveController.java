package com.workspace.admin.reserve.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.workspace.admin.reserve.service.AdminReserveService;
import com.workspace.client.reserve.vo.ReserveListVO;
import com.workspace.client.reserve.vo.ReserveVO;

@Controller
@RequestMapping(value = "/admin/reserve")
public class AdminReserveController {

	@Autowired
	private AdminReserveService adminReserveService;

	// 공용공간 예약 리스트 출력
	@RequestMapping(value = "/reserveInfo", method = RequestMethod.GET)
	public String reserveInfo(HttpServletRequest request, Model model) {
		
		if(request.getSession().getAttribute("id") == null) {
			return "redirect:/admin/login";
        }
		
		String _section = request.getParameter("section");
		String _pageNum = request.getParameter("pageNum");
		
		int section = Integer.parseInt(((_section == null) ? "1" : _section));
		int pageNum = Integer.parseInt(((_pageNum == null) ? "1" : _pageNum));
		
		Map<String, Integer> pagingMap = new HashMap<String, Integer>();
		pagingMap.put("section", section);
		pagingMap.put("pageNum", pageNum);
		
		Map<String, Object> reserveListMap = adminReserveService.reserveList(pagingMap);
		reserveListMap.put("section", section);
		reserveListMap.put("pageNum", pageNum);
		
		model.addAttribute("reserveListMap", reserveListMap);
		
		return "admin/reserve/reserveInfo";
	}
	
	// 공용공간 예약 리스트 출력(카테고리 선택값, 회사명 입력값으로 조회)
	@RequestMapping (value = "/reserveInfo", method = RequestMethod.POST)
	public String reserveInfo(@RequestParam("use_date") String use_date,
							  @RequestParam("reserve_state") String reserve_state,
							  @RequestParam("w_apply") String w_apply,
							  @RequestParam("w_state") String w_state,
							  @RequestParam("comp_name") String comp_name,
							  @RequestParam("section") String section,
							  @RequestParam("pageNum") String pageNum,
							  Model model) {
		
		Map<String, Object> pagingMap = new HashMap<String, Object>();
		pagingMap.put("section", section);
		pagingMap.put("pageNum", pageNum);
		pagingMap.put("use_date", use_date);
		pagingMap.put("reserve_state", reserve_state);
		pagingMap.put("w_apply", w_apply);
		pagingMap.put("w_state", w_state);
		pagingMap.put("comp_name", comp_name);
		
		Map<String, Object> reserveListMap = adminReserveService.reserveListSearch(pagingMap);		
		reserveListMap.put("section", section);
		reserveListMap.put("pageNum", pageNum);
		reserveListMap.put("use_date", use_date); // 선택한 카테고리를 그대로 jsp로 넘기기 위함
		reserveListMap.put("reserve_state", reserve_state); // 선택한 카테고리를 그대로 jsp로 넘기기 위함
		reserveListMap.put("w_apply", w_apply); // 선택한 카테고리를 그대로 jsp로 넘기기 위함
		reserveListMap.put("w_state", w_state); // 선택한 카테고리를 그대로 jsp로 넘기기 위함
		reserveListMap.put("comp_name", comp_name); // 입력한 키워드를 그대로 jsp로 넘기기 위함
		
		model.addAttribute("reserveListMap", reserveListMap);
		
		return "admin/reserve/adminReserveInfoAjax";
	}
	
	// 공용공간 예약 수정(예약완료, 예약취소)
	@RequestMapping(value = "/reserveUpdate", method = RequestMethod.POST)
	public String reserveUpdate(@ModelAttribute(value = "ReserveListVO") ReserveListVO reserveListVO, Model model) {
		
		List<ReserveVO> reserveList = reserveListVO.getReserveList();
		ReserveVO rvo = new ReserveVO();
		int result = 0;
		
		for (int i = 0; i < reserveList.size(); i++) {
			rvo = reserveList.get(i);
			
			if (rvo.getReserve_state().equals("예약완료") && rvo.getW_state() == null) {
				// 예약완료하는 경우
				if (adminReserveService.reserveApproval(rvo) == 1) {
					result = 1;
				} else {
					result = 0;
					break;
				}
			} else if (rvo.getReserve_state().equals("예약취소") && rvo.getW_state() == null) {
				// 예약취소로 돌리는 경우(예약 강제 취소) 및 이용시간 리셋
				if (adminReserveService.reserveDisapproval(rvo) == 1) {
					result = 1;
				} else {
					result = 0;
					break;
				}
			} else if (rvo.getReserve_state().equals("예약완료") && rvo.getW_state().equals("예약취소완료")) {
				// 취소승인하는 경우(고객의 취소 요청)
				if (adminReserveService.reserveWithdrawalApproval(rvo) == 1) {
					result = 1;
				} else {
					result = 0;
					break;
				}
			} else {
				result = 1;
			}
		}
		
		if (result == 0) {
			model.addAttribute("msg", "저장 실패");
			model.addAttribute("url", "/admin/reserve/reserveInfo");
		} else if (result == 1) {
			model.addAttribute("msg", "저장 성공");
			model.addAttribute("url", "/admin/reserve/reserveInfo");
		}
		
		return "redirect"; // 알림창 jsp 호출
	}
}
