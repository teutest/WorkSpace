package com.workspace.admin.reserve.dao;

import java.util.List;
import java.util.Map;

import com.workspace.client.reserve.vo.ReserveVO;

public interface AdminReserveDAO {

	// 공용공간 예약 리스트 출력
	public List<ReserveVO> reserveList(Map<String, Integer> pagingMap);
	
	// 전체 공용공간 예약 리스트 수 조회
	public int totReserveList();
	
	// 공용공간 예약 리스트 출력(카테고리 선택값, 회사명 입력값으로 조회)
	public List<ReserveVO> reserveListSearch(Map<String, Object> pagingMap);
	
	// 카테고리, 키워드 조건에 맞는 공용공간 예약 리스트 수 조회
	public int reserveListCnt(Map<String, Object> pagingMap);
	
	// 공용공간 예약 수정 - 예약완료
	public int reserveApproval(ReserveVO rvo);
	
	// 공용공간 예약 수정 - 예약취소(예약 강제 취소) 및 이용시간 리셋
	public int reserveDisapproval(ReserveVO rvo);
	
	// 공용공간 예약 수정 - 취소승인(고객의 취소 요청)
	public int reserveWithdrawalApproval(ReserveVO rvo);
}
