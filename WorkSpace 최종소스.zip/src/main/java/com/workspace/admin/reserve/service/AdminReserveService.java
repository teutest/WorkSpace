package com.workspace.admin.reserve.service;

import java.util.Map;

import com.workspace.client.reserve.vo.ReserveVO;

public interface AdminReserveService {

	// 공용공간 예약 리스트 출력
	public Map<String, Object> reserveList(Map<String, Integer> pagingMap);
	
	// 공용공간 예약 리스트 출력(카테고리 선택값, 회사명 입력값으로 조회)
	public Map<String, Object> reserveListSearch(Map<String, Object> pagingMap);
	
	// 공용공간 예약 수정 - 예약완료
	public int reserveApproval(ReserveVO rvo);
	
	// 공용공간 예약 수정 - 예약취소(예약 강제 취소) 및 이용시간 리셋
	public int reserveDisapproval(ReserveVO rvo);
	
	// 공용공간 예약 수정 - 취소승인(고객의 취소 요청)
	public int reserveWithdrawalApproval(ReserveVO rvo);
}
