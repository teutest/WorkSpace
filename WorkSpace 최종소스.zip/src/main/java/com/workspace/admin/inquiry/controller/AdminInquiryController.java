package com.workspace.admin.inquiry.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.workspace.admin.inquiry.service.AdminInquiryService;
import com.workspace.client.inquiry.vo.InquiryVO;

@Controller
@RequestMapping(value = "/admin/inquiry")
public class AdminInquiryController {
	
	@Autowired
	private AdminInquiryService adminInquiryService;
	
	// 문의게시판 리스트 출력
	@RequestMapping(value = "/inquiryList", method = RequestMethod.GET)
	public String inquiryList(HttpServletRequest request, Model model) {
		
		if(request.getSession().getAttribute("id") == null) {
			return "redirect:/admin/login";
        }
		
		String _section = request.getParameter("section");
		String _pageNum = request.getParameter("pageNum");
		
		int section = Integer.parseInt(((_section == null) ? "1" : _section));
		int pageNum = Integer.parseInt(((_pageNum == null) ? "1" : _pageNum));
		
		Map<String, Integer> pagingMap = new HashMap<String, Integer>();
		pagingMap.put("section", section);
		pagingMap.put("pageNum", pageNum);
		
		Map<String, Object> inquiryListMap = adminInquiryService.inquiryList(pagingMap);
		inquiryListMap.put("section", section);
		inquiryListMap.put("pageNum", pageNum);
		
		model.addAttribute("inquiryListMap", inquiryListMap);
		model.addAttribute("board", "inquiry");
		
		return "admin/inquiry/adminInquiryList";
	}
	
	// 문의게시판 리스트 출력(답변/미답변 카테고리 선택값으로 조회)
	@RequestMapping (value = "/inquiryList", method = RequestMethod.POST)
	public String inquiryList(@RequestParam("i_reply") String i_reply,
							  @RequestParam("section") String section,
							  @RequestParam("pageNum") String pageNum,
							  Model model) {
		
		Map<String, Object> pagingMap = new HashMap<String, Object>();
		pagingMap.put("section", section);
		pagingMap.put("pageNum", pageNum);
		pagingMap.put("i_reply", i_reply);
		
		Map<String, Object> inquiryListMap = adminInquiryService.inquiryListSearch(pagingMap);
		inquiryListMap.put("section", section);
		inquiryListMap.put("pageNum", pageNum);
		inquiryListMap.put("i_reply", i_reply); // 선택한 카테고리를 그대로 jsp로 넘기기 위함
		
		model.addAttribute("inquiryListMap", inquiryListMap);
		model.addAttribute("board", "inquiry");
		
		return "admin/inquiry/adminInquiryListAjax";
	}
	
	// 문의글 상세보기
	@RequestMapping (value = "/inquiryDetail", method = RequestMethod.GET)
	public String inquiryDetail(@RequestParam("i_num") String i_num,
								HttpServletRequest request,
								Model model) {
		
		if(request.getSession().getAttribute("id") == null) {
			return "redirect:/admin/login";
        }
		
		InquiryVO ivo = adminInquiryService.inquiryDetail(Integer.parseInt(i_num));
		
		model.addAttribute("ivo", ivo);
		model.addAttribute("board", "inquiry");
	
		return "admin/inquiry/adminInquiryDetail";
	}
	
	// 답변 등록
	@RequestMapping (value = "/inquiryReReg", method = RequestMethod.POST)
	public String inquiryReReg(@ModelAttribute(value = "InquiryVO") InquiryVO ivo,
							   Model model) {
		
		ivo.setI_name("WorkSpace");
		ivo.setI_reply(" "); // 답변글이기 때문에 미답변으로 조회 시 나타나지 않도록
		
		int result = adminInquiryService.inquiryReInsert(ivo);
		
		if (result == 0) {
			model.addAttribute("msg", "답변 등록 실패");
			model.addAttribute("url", "/admin/inquiry/inquiryDetail?i_num=" + ivo.getI_parent_num());
		} else if (result == 1) {
			model.addAttribute("msg", "답변 등록 성공");
			model.addAttribute("url", "/admin/inquiry/inquiryReplyDetail?i_parent_num=" + ivo.getI_parent_num());
		}
		
		return "redirect"; // 알림창 jsp 호출
	}
	
	// 답변글 상세보기
	@RequestMapping (value = "/inquiryReplyDetail", method = RequestMethod.GET)
	public String inquiryReplyDetail(@RequestParam("i_parent_num") String i_parent_num,
									 HttpServletRequest request,
									 Model model) {
		
		if(request.getSession().getAttribute("id") == null) {
			return "redirect:/admin/login";
        }
		
		InquiryVO ivo = new InquiryVO();
		InquiryVO reivo = new InquiryVO();
		
		// 문의글 정보 가져오기
		ivo = adminInquiryService.inquiryDetail(Integer.parseInt(i_parent_num));
		
		// 부모글 번호로 답변글 번호 조회
		int rei_num = adminInquiryService.selectI_num(Integer.parseInt(i_parent_num));
		
		// 답변글 정보 가져오기
		reivo = adminInquiryService.inquiryDetail(rei_num);
		
		model.addAttribute("ivo", ivo);
		model.addAttribute("reivo", reivo);
		model.addAttribute("board", "inquiry");
	
		return "admin/inquiry/adminInquiryReplyDetail";
	}
	
	// 답변 수정
	@RequestMapping (value = "/inquiryReMod", method = RequestMethod.POST)
	public String inquiryReMod(@ModelAttribute(value = "InquiryVO") InquiryVO ivo,
							   Model model) {
		
		int result = adminInquiryService.inquiryReUpdate(ivo);
		
		if (result == 0) {
			model.addAttribute("msg", "답변 수정 실패");
			model.addAttribute("url", "/admin/inquiry/inquiryReplyDetail?i_parent_num=" + ivo.getI_parent_num());
		} else if (result == 1) {
			model.addAttribute("msg", "답변 수정 성공");
			model.addAttribute("url", "/admin/inquiry/inquiryReplyDetail?i_parent_num=" + ivo.getI_parent_num());
		}
		
		return "redirect"; // 알림창 jsp 호출
	}
	
	// 답변 삭제
	@RequestMapping (value = "/inquiryReDel", method = RequestMethod.POST)
	public String inquiryReDel(@ModelAttribute(value = "InquiryVO") InquiryVO ivo,
							   Model model) {
		
		int result = adminInquiryService.inquiryReDelete(ivo);
		
		if (result == 0) {
			model.addAttribute("msg", "답변 삭제 실패");
			model.addAttribute("url", "/admin/inquiry/inquiryDetail?i_num=" + ivo.getI_parent_num());
		} else if (result == 1) {
			model.addAttribute("msg", "답변 삭제 성공");
			model.addAttribute("url", "/admin/inquiry/inquiryDetail?i_num=" + ivo.getI_parent_num());
		}
		
		return "redirect"; // 알림창 jsp 호출
	}
}
