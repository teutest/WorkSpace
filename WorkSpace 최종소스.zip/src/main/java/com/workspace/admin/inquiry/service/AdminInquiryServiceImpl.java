package com.workspace.admin.inquiry.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.workspace.admin.inquiry.dao.AdminInquiryDAO;
import com.workspace.client.inquiry.dao.InquiryDAO;
import com.workspace.client.inquiry.vo.InquiryVO;

@Service
@Transactional
public class AdminInquiryServiceImpl implements AdminInquiryService {
	
	@Autowired
	private AdminInquiryDAO adminInquiryDAO;
	
	@Autowired
	private InquiryDAO inquiryDAO;

	@Override
	// 문의게시판 리스트 출력
	public Map<String, Object> inquiryList(Map<String, Integer> pagingMap) {
		Map<String, Object> inquiryListMap = new HashMap<String, Object>();
		
		// 문의게시판 리스트 출력
		List<InquiryVO> inquiryList = adminInquiryDAO.inquiryList(pagingMap);
		
		// 전체 문의게시판 리스트 수 조회
		int totInquiryList = adminInquiryDAO.totInquiryList();
		
		inquiryListMap.put("inquiryList", inquiryList);
		inquiryListMap.put("totInquiryList", totInquiryList);	
		
		return inquiryListMap;
	}

	@Override
	// 문의게시판 리스트 출력(답변/미답변 카테고리 선택값으로 조회)
	public Map<String, Object> inquiryListSearch(Map<String, Object> pagingMap) {
		Map<String, Object> inquiryListMap = new HashMap<String, Object>();
		
		// 문의게시판 리스트 출력(답변/미답변 카테고리 선택값으로 조회)
		List<InquiryVO> inquiryList = adminInquiryDAO.inquiryListSearch(pagingMap);
		
		// 답변/미답변 카테고리 조건에 맞는 문의게시판 리스트 수 조회
		int inquiryListCnt = adminInquiryDAO.inquiryListCnt(pagingMap);
		
		inquiryListMap.put("inquiryList", inquiryList);
		inquiryListMap.put("inquiryListCnt", inquiryListCnt);
		
		return inquiryListMap;
	}
	
	@Override
	// 글 상세보기
	public InquiryVO inquiryDetail(int i_num) {
		return adminInquiryDAO.inquiryDetail(i_num);
	}
	
	@Override
	// 답변 등록
	public int inquiryReInsert(InquiryVO ivo) {
		
		// 전체 문의게시판 리스트 수 조회 후 1 더한 값을 글 번호로 부여
		int i_num = inquiryDAO.maxI_num() + 1;
		ivo.setI_num(i_num);
		
		// 답변 등록
		try {
			if (adminInquiryDAO.inquiryReInsert(ivo) == 1) {
				// 답변 등록 성공 시 사용자 게시글 답변여부 컬럼을 '답변' 상태로 변경
				if (adminInquiryDAO.i_replyAnswer(ivo.getI_parent_num()) == 1) {
					return 1; // 답변등록 성공
				} else {
					return 0; // 답변등록 실패(사용자 게시글 답변여부 컬럼 '답변' 상태로 변경 실패)
				}
			} else {
				return 0; // 답변등록 실패(답변 insert 실패)
			}
		} catch (Exception e) {
			e.printStackTrace();
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return 0; // 답변등록 실패(예외 발생)
		}
		
	}
	
	@Override
	// 부모글 번호로 답변글 번호 조회
	public int selectI_num(int i_parent_num) {
		return adminInquiryDAO.selectI_num(i_parent_num);
	}
	
	@Override
	// 답변 수정
	public int inquiryReUpdate(InquiryVO ivo) {
		return adminInquiryDAO.inquiryReUpdate(ivo);
	}
	
	@Override
	// 답변 삭제
	public int inquiryReDelete(InquiryVO ivo) {
		
		try {
			if (adminInquiryDAO.inquiryReDelete(ivo) == 1) {
				// 답변 삭제 성공 시 사용자 게시글 답변여부 컬럼을 '미답변' 상태로 변경
				if (adminInquiryDAO.i_replyUnanswer(ivo.getI_parent_num()) == 1) {
					return 1; // 답변삭제 성공
				} else {
					return 0; // 답변삭제 실패(사용자 게시글 답변여부 컬럼 '미답변' 상태로 변경 실패)
				}
			} else {
				return 0; // 답변삭제 실패(답변 delete 실패)
			}
		} catch (Exception e) {
			e.printStackTrace();
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return 0; // 답변삭제 실패(예외 발생)
		}
		
	}

}
