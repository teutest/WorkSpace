package com.workspace.admin.inquiry.dao;

import java.util.List;
import java.util.Map;

import com.workspace.client.inquiry.vo.InquiryVO;

public interface AdminInquiryDAO {
	
	// 문의게시판 리스트 출력
	public List<InquiryVO> inquiryList(Map<String, Integer> pagingMap);
	
	// 전체 문의게시판 리스트 수 조회
	public int totInquiryList();
		
	// 문의게시판 리스트 출력(답변/미답변 카테고리 선택값으로 조회)
	public List<InquiryVO> inquiryListSearch(Map<String, Object> pagingMap);
	
	// 답변/미답변 카테고리 조건에 맞는 문의게시판 리스트 수 조회
	public int inquiryListCnt(Map<String, Object> pagingMap);
	
	// 글 상세보기
	public InquiryVO inquiryDetail(int i_num);
	
	// 답변 등록
	public int inquiryReInsert(InquiryVO ivo);
	
	// 사용자 게시글 답변여부 컬럼을 '답변' 상태로 변경
	public int i_replyAnswer(int i_num);
	
	// 부모글 번호로 답변글 번호 조회
	public int selectI_num(int i_parent_num);
	
	// 답변 수정
	public int inquiryReUpdate(InquiryVO ivo);
	
	// 답변 삭제
	public int inquiryReDelete(InquiryVO ivo);
	
	// 사용자 게시글 답변여부 컬럼을 '답변' 상태로 변경
	public int i_replyUnanswer(int i_num);

}
