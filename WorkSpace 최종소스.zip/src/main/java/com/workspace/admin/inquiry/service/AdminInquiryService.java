package com.workspace.admin.inquiry.service;

import java.util.Map;

import com.workspace.client.inquiry.vo.InquiryVO;

public interface AdminInquiryService {

	// 문의게시판 리스트 출력
	public Map<String, Object> inquiryList(Map<String, Integer> pagingMap);
	
	// 문의게시판 리스트 출력(답변/미답변 카테고리 선택값으로 조회)
	public Map<String, Object> inquiryListSearch(Map<String, Object> pagingMap);
	
	// 글 상세보기
	public InquiryVO inquiryDetail(int i_num);
	
	// 답변 등록
	public int inquiryReInsert(InquiryVO ivo);
	
	// 부모글 번호로 답변글 번호 조회
	public int selectI_num(int i_parent_num);
	
	// 답변 수정
	public int inquiryReUpdate(InquiryVO ivo);
	
	// 답변 삭제
	public int inquiryReDelete(InquiryVO ivo);
	
}
