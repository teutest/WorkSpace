package com.workspace.admin.inquiry.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.workspace.client.inquiry.vo.InquiryVO;

@Repository
public class AdminInquiryDAOImpl implements AdminInquiryDAO {
	
	@Autowired
	private SqlSession session;

	@Override
	// 문의게시판 리스트 출력
	public List<InquiryVO> inquiryList(Map<String, Integer> pagingMap) {
		return session.selectList("inquiryList", pagingMap);
	}

	@Override
	// 전체 문의게시판 리스트 수 조회
	public int totInquiryList() {
		return session.selectOne("totInquiryList");
	}

	@Override
	// 문의게시판 리스트 출력(답변/미답변 카테고리 선택값으로 조회)
	public List<InquiryVO> inquiryListSearch(Map<String, Object> pagingMap) {
		return session.selectList("inquiryListSearch", pagingMap);
	}

	@Override
	// 답변/미답변 카테고리 조건에 맞는 문의게시판 리스트 수 조회
	public int inquiryListCnt(Map<String, Object> pagingMap) {
		return session.selectOne("inquiryListCnt", pagingMap);
	}
	
	@Override
	// 글 상세보기
	public InquiryVO inquiryDetail(int i_num) {
		return session.selectOne("inquiryDetail", i_num);
	}
	
	@Override
	// 답변 등록
	public int inquiryReInsert(InquiryVO ivo) {
		return session.insert("inquiryReInsert", ivo);
	}
	
	@Override
	// 사용자 게시글 답변여부 컬럼을 '답변' 상태로 변경
	public int i_replyAnswer(int i_num) {
		return session.update("i_replyAnswer", i_num);
	}
	
	@Override
	// 부모글 번호로 답변글 번호 조회
	public int selectI_num(int i_parent_num) {
		return session.selectOne("selectI_num", i_parent_num);
	}
	
	@Override
	// 답변 수정
	public int inquiryReUpdate(InquiryVO ivo) {
		return session.update("inquiryReUpdate", ivo);
	}
	
	@Override
	// 답변 삭제
	public int inquiryReDelete(InquiryVO ivo) {
		return session.delete("inquiryReDelete", ivo);
	}
	
	@Override
	// 사용자 게시글 답변여부 컬럼을 '미답변' 상태로 변경
	public int i_replyUnanswer(int i_num) {
		return session.update("i_replyUnanswer", i_num);
	}

}
