package com.workspace.admin.login.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping(value = "/admin")
public class AdminLoginController {
	
	// 로그인 페이지 직접 접근 시
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String loginGET(HttpServletRequest request) {
		if(request.getSession().getAttribute("id") != null) {
			return "main";
        }
		return "login";
	}
	
	// 로그인 성공 시
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String loginPOST(String inputId, String inputPw, HttpSession session) {
		session.setAttribute("id", inputId);
		return "redirect:/admin/main";
	}
	
	// 메인 페이지 직접 접근 시
	@RequestMapping(value = "/main", method = RequestMethod.GET)
	public String main(HttpServletRequest request) {
		if(request.getSession().getAttribute("id") == null) {
			return "redirect:/admin/login";
        }
		
        return "redirect:/admin/member/contractInfo";
	}
	
	// 로그아웃 처리
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession session, HttpServletRequest request) {
		session.invalidate();
		session = request.getSession(true);
		return "redirect:/admin/main";
	}

}
