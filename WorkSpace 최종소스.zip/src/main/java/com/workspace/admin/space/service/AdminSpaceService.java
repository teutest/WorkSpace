package com.workspace.admin.space.service;

import java.util.Map;

import com.workspace.client.space.vo.SpaceVO;

public interface AdminSpaceService {
	
	// 사무공간 리스트 출력
	public Map<String, Object> privateList(Map<String, Integer> pagingMap);
	
	// 사무공간 리스트 출력(카테고리 선택값, 공간명 입력값으로 조회)
	public Map<String, Object> privateListSearch(Map<String, Object> pagingMap);
	
	// 공용공간 리스트 출력
	public Map<String, Object> publicList(Map<String, Integer> pagingMap);
	
	// 공용공간 리스트 출력(카테고리 선택값, 공간명 입력값으로 조회)
	public Map<String, Object> publicListSearch(Map<String, Object> pagingMap);
	
	// 공간 사용현황 '사용가능'으로 수정
	public int s_stateUsable(String s_name);
	
	// 공간 사용현황 '사용불가'로 수정
	public int s_stateUnusable(String s_name);
	
	// 사무공간 공간명에 사용할 시퀀스 조회
	public int findSeq(String str);
	
	// 공간명 중복 체크
	public int s_nameConfirm(String s_name);
	
	// 공간 등록
	public int spaceInsert(SpaceVO svo);
	
	// 공간 수정 페이지 출력
	public SpaceVO spaceModForm(String s_name);
	
	// 공간 수정
	public int spaceUpdate(SpaceVO svo);

}
