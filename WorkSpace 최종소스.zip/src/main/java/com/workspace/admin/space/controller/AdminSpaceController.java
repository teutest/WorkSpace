package com.workspace.admin.space.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.workspace.admin.space.service.AdminSpaceService;
import com.workspace.client.common.file.FileUploadUtil;
import com.workspace.client.space.vo.SpaceListVO;
import com.workspace.client.space.vo.SpaceVO;

@Controller
@RequestMapping(value = "/admin/space")
public class AdminSpaceController {
	
	@Autowired
	private AdminSpaceService adminSpaceService;
	
	// 사무공간 리스트 출력
	@RequestMapping(value = "/privateList", method = RequestMethod.GET)
	public String privateList(HttpServletRequest request, Model model) {
		
		if(request.getSession().getAttribute("id") == null) {
			return "redirect:/admin/login";
        }
		
		String _section = request.getParameter("section");
		String _pageNum = request.getParameter("pageNum");
		
		int section = Integer.parseInt(((_section == null) ? "1" : _section));
		int pageNum = Integer.parseInt(((_pageNum == null) ? "1" : _pageNum));
		
		Map<String, Integer> pagingMap = new HashMap<String, Integer>();
		pagingMap.put("section", section);
		pagingMap.put("pageNum", pageNum);
		
		Map<String, Object> privateListMap = adminSpaceService.privateList(pagingMap);
		privateListMap.put("section", section);
		privateListMap.put("pageNum", pageNum);
		
		model.addAttribute("privateListMap", privateListMap);
		model.addAttribute("space", "privateSpace");
		
		return "admin/space/adminSpacePrivateList";
	}
	
	// 사무공간 리스트 출력(카테고리 선택값, 공간명 입력값으로 조회)
	@RequestMapping (value = "/privateList", method = RequestMethod.POST)
	public String privateList(@RequestParam("s_type") String s_type,
							  @RequestParam("s_state") String s_state,
							  @RequestParam("s_name") String s_name,
							  @RequestParam("section") String section,
							  @RequestParam("pageNum") String pageNum,
							  Model model) {
		
		Map<String, Object> pagingMap = new HashMap<String, Object>();
		pagingMap.put("section", section);
		pagingMap.put("pageNum", pageNum);
		pagingMap.put("s_type", s_type);
		pagingMap.put("s_state", s_state);
		pagingMap.put("s_name", s_name);
		
		Map<String, Object> privateListMap = adminSpaceService.privateListSearch(pagingMap);
		privateListMap.put("section", section);
		privateListMap.put("pageNum", pageNum);
		privateListMap.put("s_type", s_type); // 선택한 카테고리를 그대로 jsp로 넘기기 위함
		privateListMap.put("s_state", s_state); // 선택한 카테고리를 그대로 jsp로 넘기기 위함
		privateListMap.put("s_name", s_name); // 입력한 키워드를 그대로 jsp로 넘기기 위함
		
		model.addAttribute("privateListMap", privateListMap);
		model.addAttribute("space", "privateSpace");
		
		return "admin/space/adminSpacePrivateListAjax";
	}
	
	// 사무공간 리스트에서 사용현황 수정
	@RequestMapping(value = "/privateListUpdate", method = RequestMethod.POST)
	public String privateListUpdate(@ModelAttribute(value = "SpaceListVO") SpaceListVO spaceListVO, Model model) {
		
		List<SpaceVO> spaceList = spaceListVO.getSpaceList();
		SpaceVO svo = new SpaceVO();
		int result = 0;
		
		for (int i = 0; i < spaceList.size(); i++) {
			svo = spaceList.get(i);
			
			if (svo.getS_state().equals("사용가능")) {
				// 공간 사용현황을 사용가능으로 변경
				if (adminSpaceService.s_stateUsable(svo.getS_name()) == 1) {
					result = 1;
				} else {
					result = 0;
					break;
				}
			} else if (svo.getS_state().equals("사용불가")) {
				// 공간 사용현황을 사용불가로 변경
				if (adminSpaceService.s_stateUnusable(svo.getS_name()) == 1) {
					result = 1;
				} else {
					result = 0;
					break;
				}
			} else {
				result = 1;
			}
		}
		
		if (result == 0) {
			model.addAttribute("msg", "저장 실패");
			model.addAttribute("url", "/admin/space/privateList");
		} else if (result == 1) {
			model.addAttribute("msg", "저장 성공");
			model.addAttribute("url", "/admin/space/privateList");
		}
		
		return "redirect"; // 알림창 jsp 호출
	}
	
	// 사무공간 등록 페이지 출력
	@RequestMapping(value = "/privateReg", method = RequestMethod.GET)
	public String privateReg(Model model) {
		System.out.println("사무공간 등록 페이지 출력 컨트롤러");
		model.addAttribute("space", "privateSpace");
		return "admin/space/adminSpacePrivateReg";
	}
	
	// 사무공간 등록
	@RequestMapping(value = "/privateInsert", method = RequestMethod.POST)
	public String privateInsert(@RequestParam("s_pop") String s_pop,
								@RequestParam("s_type") String s_type,
								@RequestParam("s_price") String s_price,
								@RequestParam("s_state") String s_state,
								@RequestParam("s_exp") String s_exp,
								@RequestParam("file") MultipartFile file,
								@RequestParam("s_note") String s_note,
								Model model,
								HttpServletRequest request) throws IllegalStateException, IOException {
		
		System.out.println("사무공간 등록 컨트롤러");
		
		int result = 0; // 사무공간 DB insert 실행 결과
		int seq = 0; // 공간명 설정에 필요한 시퀀스
		
		// SpaceVO 인스턴스 생성 및 필드값 설정
		SpaceVO svo = new SpaceVO();
		svo.setS_pop(s_pop);
		svo.setS_type(s_type);
		svo.setS_price(Integer.parseInt(s_price));
		svo.setS_exp(s_exp);
		svo.setS_note(s_note);
		svo.setS_state(s_state);
		
		// SpaceVO 인스턴스 공간명 설정
		if (s_type.equals("1인 데스크")) {
			seq = adminSpaceService.findSeq("desk1");
			if (seq >= 1 && seq <= 9) {
				svo.setS_name("DESK10" + seq);
			} else {
				svo.setS_name("DESK1" + seq);
			}
		} else if (s_type.equals("프라이빗 오피스 1인실")) {
			seq = adminSpaceService.findSeq("office1");
			if (seq >= 1 && seq <= 9) {
				svo.setS_name("OFFICE10" + seq);
			} else {
				svo.setS_name("OFFICE1" + seq);
			}
		} else if (s_type.equals("프라이빗 오피스 2-4인실")) {
			seq = adminSpaceService.findSeq("office2");
			if (seq >= 1 && seq <= 9) {
				svo.setS_name("OFFICE20" + seq);
			} else {
				svo.setS_name("OFFICE2" + seq);
			}
		} else if (s_type.equals("프라이빗 오피스 5-7인실")) {
			seq = adminSpaceService.findSeq("office5");
			if (seq >= 1 && seq <= 9) {
				svo.setS_name("OFFICE50" + seq);
			} else {
				svo.setS_name("OFFICE5" + seq);
			}
		} else if (s_type.equals("프라이빗 오피스 8-10인실")) {
			seq = adminSpaceService.findSeq("office8");
			if (seq >= 1 && seq <= 9) {
				svo.setS_name("OFFICE80" + seq);
			} else {
				svo.setS_name("OFFICE8" + seq);
			}
		}			
		
		// 공간사진 파일 업로드 후 SpaceVO 인스턴스 파일명 설정
		if (file != null) {
			String s_photo = FileUploadUtil.fileUpload(file, request, "space");
			svo.setS_photo(s_photo);
		}
		
		// 사무공간 DB insert 실행
		result = adminSpaceService.spaceInsert(svo);
		if (result == 1) {
			model.addAttribute("msg", "사무공간 등록 성공");
			model.addAttribute("url", "/admin/space/privateList"); // 등록 성공 시 사무공간 리스트로 돌아가기
		} else {
			model.addAttribute("msg", "사무공간 등록 실패");
			model.addAttribute("url", "/admin/space/privateReg"); // 등록 실패 시 사무공간 등록 페이지로 돌아가기
		}
		
		return "redirect";
	}
	
	// 사무공간 수정 페이지 출력
	@RequestMapping(value = "/privateMod", method = RequestMethod.GET)
	public String privateMod(HttpServletRequest request, Model model) {
		if(request.getSession().getAttribute("id") == null) {
			return "redirect:/admin/login";
        }
		
		String s_name = request.getParameter("s_name");
		SpaceVO svo = adminSpaceService.spaceModForm(s_name);
		
		model.addAttribute("svo", svo);
		model.addAttribute("space", "privateSpace");
		
		return "admin/space/adminSpacePrivateMod";
	}
	
	// 사무공간 수정
	@RequestMapping(value = "/privateUpdate", method = RequestMethod.POST)
	public String privateUpdate(@ModelAttribute("SpaceVO") SpaceVO svo,
								HttpServletRequest request,
								Model model) throws IOException {
		
		int result = 0;
		
		// 새로운 이미지를 올렸을 경우
		if (!svo.getFile().isEmpty()) {
			
			// 기존 이미지가 있을 경우
			if (!svo.getS_photo().isEmpty()) {
				// 기존 이미지 삭제
				FileUploadUtil.fileDelete(svo.getS_photo(), request);
			}
			
			// 새로 업로드한 이미지로 DB 공간사진명 변경
			svo.setS_photo(FileUploadUtil.fileUpload(svo.getFile(), request, "space"));
		} 
		
		result = adminSpaceService.spaceUpdate(svo);
		
		if (result == 1) {
			model.addAttribute("msg", "사무공간 수정 성공");
			model.addAttribute("url", "/admin/space/privateList"); // 수정 성공 시 사무공간 리스트로 돌아가기
		} else {
			model.addAttribute("msg", "사무공간 수정 실패");
			model.addAttribute("url", "/admin/space/privateMod?s_name=" + svo.getS_name()); // 수정 실패 시 해당 사무공간 수정폼으로 돌아가기
		}
		
		return "redirect";
	}
	
	// 공용공간 리스트 출력
	@RequestMapping(value = "/publicList", method = RequestMethod.GET)
	public String publicList(HttpServletRequest request, Model model) {
		
		if(request.getSession().getAttribute("id") == null) {
			return "redirect:/admin/login";
        }
		
		String _section = request.getParameter("section");
		String _pageNum = request.getParameter("pageNum");
		
		int section = Integer.parseInt(((_section == null) ? "1" : _section));
		int pageNum = Integer.parseInt(((_pageNum == null) ? "1" : _pageNum));
		
		Map<String, Integer> pagingMap = new HashMap<String, Integer>();
		pagingMap.put("section", section);
		pagingMap.put("pageNum", pageNum);
		
		Map<String, Object> publicListMap = adminSpaceService.publicList(pagingMap);
		publicListMap.put("section", section);
		publicListMap.put("pageNum", pageNum);
		
		model.addAttribute("publicListMap", publicListMap);
		model.addAttribute("space", "publicSpace");
		
		return "admin/space/adminSpacePublicList";
	}
	
	// 공용공간 리스트 출력(카테고리 선택값, 공간명 입력값으로 조회)
	@RequestMapping (value = "/publicList", method = RequestMethod.POST)
	public String publicList(@RequestParam("s_state") String s_state,
							 @RequestParam("s_name") String s_name,
							 @RequestParam("section") String section,
							 @RequestParam("pageNum") String pageNum,
							 Model model) {
		
		Map<String, Object> pagingMap = new HashMap<String, Object>();
		pagingMap.put("section", section);
		pagingMap.put("pageNum", pageNum);
		pagingMap.put("s_state", s_state);
		pagingMap.put("s_name", s_name);
		
		Map<String, Object> publicListMap = adminSpaceService.publicListSearch(pagingMap);
		publicListMap.put("section", section);
		publicListMap.put("pageNum", pageNum);
		publicListMap.put("s_state", s_state); // 선택한 카테고리를 그대로 jsp로 넘기기 위함
		publicListMap.put("s_name", s_name); // 입력한 키워드를 그대로 jsp로 넘기기 위함
		
		model.addAttribute("publicListMap", publicListMap);
		model.addAttribute("space", "publicSpace");
		
		return "admin/space/adminSpacePublicListAjax";
	}
	
	// 공용공간 리스트에서 사용현황 수정
	@RequestMapping(value = "/publicListUpdate", method = RequestMethod.POST)
	public String publicListUpdate(@ModelAttribute(value = "SpaceListVO") SpaceListVO spaceListVO, Model model) {
		
		List<SpaceVO> spaceList = spaceListVO.getSpaceList();
		SpaceVO svo = new SpaceVO();
		int result = 0;
		
		for (int i = 0; i < spaceList.size(); i++) {
			svo = spaceList.get(i);
			
			if (svo.getS_state().equals("사용가능")) {
				// 공간 사용현황을 사용가능으로 변경
				if (adminSpaceService.s_stateUsable(svo.getS_name()) == 1) {
					result = 1;
				} else {
					result = 0;
					break;
				}
			} else if (svo.getS_state().equals("사용불가")) {
				// 공간 사용현황을 사용불가로 변경
				if (adminSpaceService.s_stateUnusable(svo.getS_name()) == 1) {
					result = 1;
				} else {
					result = 0;
					break;
				}
			} else {
				result = 1;
			}
		}
		
		if (result == 0) {
			model.addAttribute("msg", "저장 실패");
			model.addAttribute("url", "/admin/space/publicList");
		} else if (result == 1) {
			model.addAttribute("msg", "저장 성공");
			model.addAttribute("url", "/admin/space/publicList");
		}
		
		return "redirect"; // 알림창 jsp 호출
	}
	
	// 공용공간 등록 페이지 출력
	@RequestMapping(value = "/publicReg", method = RequestMethod.GET)
	public String publicReg(Model model) {
		System.out.println("공용공간 등록 페이지 출력 컨트롤러");
		model.addAttribute("space", "publicSpace");
		return "admin/space/adminSpacePublicReg";
	}
	
	// 공간명 중복 체크
	@ResponseBody
	@RequestMapping(value = "/s_nameConfirm", method = RequestMethod.POST)
	public String s_nameConfirm(@RequestParam("s_name") String s_name) {
		System.out.println("공간명 중복검사 컨트롤러");
		
		int result = adminSpaceService.s_nameConfirm(s_name);
		return result + "";
	}
	
	// 공용공간 등록
	@RequestMapping(value = "/publicInsert", method = RequestMethod.POST)
	public String publicInsert(@RequestParam("s_pop") String s_pop,
							   @RequestParam("s_type") String s_type,
							   @RequestParam("s_name") String s_name,
							   @RequestParam("s_price") String s_price,
							   @RequestParam("s_state") String s_state,
							   @RequestParam("s_exp") String s_exp,
							   @RequestParam("file") MultipartFile file,
							   @RequestParam("s_note") String s_note,
							   Model model,
							   HttpServletRequest request) throws IllegalStateException, IOException {
		
		System.out.println("공용공간 등록 컨트롤러");
		
		int result = 0; // 공용공간 DB insert 실행 결과
		
		// SpaceVO 인스턴스 생성 및 필드값 설정
		SpaceVO svo = new SpaceVO();
		svo.setS_name(s_name);
		svo.setS_pop(s_pop);
		svo.setS_type(s_type);
		svo.setS_price(Integer.parseInt(s_price));
		svo.setS_exp(s_exp);
		svo.setS_note(s_note);
		svo.setS_state(s_state);
				
		// 공간사진 파일 업로드 후 SpaceVO 인스턴스 파일명 설정
		if (file != null) {
			String s_photo = FileUploadUtil.fileUpload(file, request, "space");
			svo.setS_photo(s_photo);
		}
		
		// 공용공간 DB insert 실행
		result = adminSpaceService.spaceInsert(svo);
		if (result == 1) {
			model.addAttribute("msg", "공용공간 등록 성공");
			model.addAttribute("url", "/admin/space/publicList"); // 등록 성공 시 공용공간 리스트로 돌아가기
		} else {
			model.addAttribute("msg", "공용공간 등록 실패");
			model.addAttribute("url", "/admin/space/publicReg"); // 등록 실패 시 공용공간 등록 페이지로 돌아가기
		}
		
		return "redirect";
	}
	
	// 공용공간 수정 페이지 출력
	@RequestMapping(value = "/publicMod", method = RequestMethod.GET)
	public String publicMod(HttpServletRequest request, Model model) {
		if(request.getSession().getAttribute("id") == null) {
			return "redirect:/admin/login";
        }
		
		String s_name = request.getParameter("s_name");
		SpaceVO svo = adminSpaceService.spaceModForm(s_name);
		
		model.addAttribute("svo", svo);
		model.addAttribute("space", "publicSpace");
		
		return "admin/space/adminSpacePublicMod";
	}
	
	// 공용공간 수정
	@RequestMapping(value = "/publicUpdate", method = RequestMethod.POST)
	public String publicUpdate(@ModelAttribute("SpaceVO") SpaceVO svo,
							   HttpServletRequest request,
							   Model model) throws IOException {
		
		int result = 0;
		
		// 새로운 이미지를 올렸을 경우
		if (!svo.getFile().isEmpty()) {
			
			// 기존 이미지가 있을 경우
			if (!svo.getS_photo().isEmpty()) {
				// 기존 이미지 삭제
				FileUploadUtil.fileDelete(svo.getS_photo(), request);
			}
			
			// 새로 업로드한 이미지로 DB 공간사진명 변경
			svo.setS_photo(FileUploadUtil.fileUpload(svo.getFile(), request, "space"));
		} 
		
		result = adminSpaceService.spaceUpdate(svo);
		
		if (result == 1) {
			model.addAttribute("msg", "공용공간 수정 성공");
			model.addAttribute("url", "/admin/space/publicList"); // 수정 성공 시 공용공간 리스트로 돌아가기
		} else {
			model.addAttribute("msg", "공용공간 수정 실패");
			model.addAttribute("url", "/admin/space/publicMod?s_name=" + svo.getS_name()); // 수정 실패 시 해당 공용공간 수정폼으로 돌아가기
		}
		
		return "redirect";
	}
}
