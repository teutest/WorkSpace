package com.workspace.admin.space.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.workspace.client.space.vo.SpaceVO;

@Repository
public class AdminSpaceDAOImpl implements AdminSpaceDAO {
	
	@Autowired
	private SqlSession session;
	
	@Override
	// 사무공간 리스트 출력
	public List<SpaceVO> privateList(Map<String, Integer> pagingMap) {
		return session.selectList("privateList", pagingMap);
	}

	@Override
	// 전체 사무공간 리스트 수 조회
	public int totPrivateList() {
		return session.selectOne("totPrivateList");
	}

	@Override
	// 사무공간 리스트 출력(카테고리 선택값, 공간명 입력값으로 조회)
	public List<SpaceVO> privateListSearch(Map<String, Object> pagingMap) {
		return session.selectList("privateListSearch", pagingMap);
	}

	@Override
	// 카테고리, 키워드 조건에 맞는 사무공간 리스트 수 조회
	public int privateListCnt(Map<String, Object> pagingMap) {
		return session.selectOne("privateListCnt", pagingMap);
	}
	
	@Override
	// 공용공간 리스트 출력
	public List<SpaceVO> publicList(Map<String, Integer> pagingMap) {
		return session.selectList("publicList", pagingMap);
	}

	@Override
	// 전체 공용공간 리스트 수 조회
	public int totPublicList() {
		return session.selectOne("totPublicList");
	}

	@Override
	// 공용공간 리스트 출력(카테고리 선택값, 공간명 입력값으로 조회)
	public List<SpaceVO> publicListSearch(Map<String, Object> pagingMap) {
		return session.selectList("publicListSearch", pagingMap);
	}

	@Override
	// 카테고리, 키워드 조건에 맞는 공용공간 리스트 수 조회
	public int publicListCnt(Map<String, Object> pagingMap) {
		return session.selectOne("publicListCnt", pagingMap);
	}

	@Override
	// 공간 사용현황 '사용가능'으로 수정
	public int s_stateUsable(String s_name) {
		return session.update("s_stateUsable", s_name);
	}

	@Override
	// 공간 사용현황 '사용불가'로 수정
	public int s_stateUnusable(String s_name) {
		return session.update("s_stateUnusable", s_name);
	}
	
	// 사무공간 공간명에 사용할 시퀀스 조회
	@Override
	public int findSeq(String str) {
		System.out.println("사무공간 공간명에 사용할 시퀀스 조회 DAO");
		return session.selectOne("findSeq", str);
	}
	
	// 공간명으로 공간 조회
	@Override
	public SpaceVO s_nameConfirm(String s_name) {
		System.out.println("공간명으로 공간 조회 DAO");
		return session.selectOne("s_nameConfirm", s_name);
	}

	// 공간 등록
	@Override
	public int spaceInsert(SpaceVO svo) {
		System.out.println("공간 등록 DAO");
		return session.insert("spaceInsert", svo);
	}
	
	// 공간 수정 페이지 출력
	@Override
	public SpaceVO spaceModForm(String s_name) {
		return session.selectOne("spaceModForm", s_name);
	}
	
	// 공간 수정
	@Override
	public int spaceUpdate(SpaceVO svo) {
		return session.update("spaceUpdate", svo);
	}

}
