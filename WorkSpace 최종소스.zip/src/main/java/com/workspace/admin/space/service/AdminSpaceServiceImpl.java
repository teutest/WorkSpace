package com.workspace.admin.space.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.workspace.admin.space.dao.AdminSpaceDAO;
import com.workspace.client.space.vo.SpaceVO;

@Service
@Transactional
public class AdminSpaceServiceImpl implements AdminSpaceService {
	
	@Autowired
	private AdminSpaceDAO adminSpaceDAO;
	
	@Override
	// 사무공간 리스트 출력
	public Map<String, Object> privateList(Map<String, Integer> pagingMap) {
		Map<String, Object> privateListMap = new HashMap<String, Object>();
		
		// 사무공간 리스트 출력
		List<SpaceVO> privateList = adminSpaceDAO.privateList(pagingMap);
		
		// DB로부터 받아온 사무공간 리스트에서 공간 등록일을 Date -> String 으로 변환
		List<String> s_reg_list = new ArrayList<String>();
		Date s_reg;
		
		for (int i = 0; i < privateList.size(); i++) {
			s_reg = privateList.get(i).getS_reg();
			SimpleDateFormat fm = new SimpleDateFormat("yyyy-MM-dd");
			s_reg_list.add(fm.format(s_reg));
		}		
		
		// 전체 사무공간 리스트 수 조회
		int totPrivateList = adminSpaceDAO.totPrivateList();
		
		privateListMap.put("privateList", privateList);
		privateListMap.put("s_reg_list", s_reg_list);
		privateListMap.put("totPrivateList", totPrivateList);	
		
		return privateListMap;
	}
	
	@Override
	// 사무공간 리스트 출력(카테고리 선택값, 공간명 입력값으로 조회)
	public Map<String, Object> privateListSearch(Map<String, Object> pagingMap) {
		Map<String, Object> privateListMap = new HashMap<String, Object>();
		
		// 사무공간 리스트 출력(카테고리 선택값, 공간명 입력값으로 조회)
		List<SpaceVO> privateList = adminSpaceDAO.privateListSearch(pagingMap);
		
		// DB로부터 받아온 사무공간 리스트에서 공간 등록일을 Date -> String 으로 변환
		List<String> s_reg_list = new ArrayList<String>();
		Date s_reg;
		
		for (int i = 0; i < privateList.size(); i++) {
			s_reg = privateList.get(i).getS_reg();
			SimpleDateFormat fm = new SimpleDateFormat("yyyy-MM-dd");
			s_reg_list.add(fm.format(s_reg));
		}	
		
		// 카테고리, 키워드 조건에 맞는 사무공간 리스트 수 조회
		int privateListCnt = adminSpaceDAO.privateListCnt(pagingMap);
		
		privateListMap.put("privateList", privateList);
		privateListMap.put("s_reg_list", s_reg_list);
		privateListMap.put("privateListCnt", privateListCnt);
		
		return privateListMap;
	}
	
	@Override
	// 공용공간 리스트 출력
	public Map<String, Object> publicList(Map<String, Integer> pagingMap) {
		Map<String, Object> publicListMap = new HashMap<String, Object>();
		
		// 공용공간 리스트 출력
		List<SpaceVO> publicList = adminSpaceDAO.publicList(pagingMap);
		
		// DB로부터 받아온 공용공간 리스트에서 공간 등록일을 Date -> String 으로 변환
		List<String> s_reg_list = new ArrayList<String>();
		Date s_reg;
		
		for (int i = 0; i < publicList.size(); i++) {
			s_reg = publicList.get(i).getS_reg();
			SimpleDateFormat fm = new SimpleDateFormat("yyyy-MM-dd");
			s_reg_list.add(fm.format(s_reg));
		}		
		
		// 전체 공용공간 리스트 수 조회
		int totPublicList = adminSpaceDAO.totPublicList();
		
		publicListMap.put("publicList", publicList);
		publicListMap.put("s_reg_list", s_reg_list);
		publicListMap.put("totPublicList", totPublicList);	
		
		return publicListMap;
	}
	
	@Override
	// 공용공간 리스트 출력(카테고리 선택값, 공간명 입력값으로 조회)
	public Map<String, Object> publicListSearch(Map<String, Object> pagingMap) {
		Map<String, Object> publicListMap = new HashMap<String, Object>();
		
		// 공용공간 리스트 출력(카테고리 선택값, 공간명 입력값으로 조회)
		List<SpaceVO> publicList = adminSpaceDAO.publicListSearch(pagingMap);
		
		// DB로부터 받아온 공용공간 리스트에서 공간 등록일을 Date -> String 으로 변환
		List<String> s_reg_list = new ArrayList<String>();
		Date s_reg;
		
		for (int i = 0; i < publicList.size(); i++) {
			s_reg = publicList.get(i).getS_reg();
			SimpleDateFormat fm = new SimpleDateFormat("yyyy-MM-dd");
			s_reg_list.add(fm.format(s_reg));
		}	
		
		// 카테고리, 키워드 조건에 맞는 공용공간 리스트 수 조회
		int publicListCnt = adminSpaceDAO.publicListCnt(pagingMap);
		
		publicListMap.put("publicList", publicList);
		publicListMap.put("s_reg_list", s_reg_list);
		publicListMap.put("publicListCnt", publicListCnt);
		
		return publicListMap;
	}

	@Override
	// 공간 사용현황 '사용가능'으로 수정
	public int s_stateUsable(String s_name) {
		return adminSpaceDAO.s_stateUsable(s_name);
	}

	@Override
	// 공간 사용현황 '사용불가'로 수정
	public int s_stateUnusable(String s_name) {
		return adminSpaceDAO.s_stateUnusable(s_name);
	}

	// 사무공간 공간명에 사용할 시퀀스 조회
	@Override
	public int findSeq(String str) {
		System.out.println("사무공간 공간명에 사용할 시퀀스 조회 서비스");
		return adminSpaceDAO.findSeq(str);
	}
	
	// 공간명 중복 체크
	@Override
	public int s_nameConfirm(String s_name) {
		System.out.println("공간명 중복체크 서비스");
		
		if (adminSpaceDAO.s_nameConfirm(s_name) != null) {
			// 공간명 중복
			return 1;
		} else {
			// 공간명 중복 아님
			return 2;
		}
	}
	
	// 공간 등록
	@Override
	public int spaceInsert(SpaceVO svo) {
		System.out.println("공간 등록 서비스");
		int result = 0;
		try {
			result = adminSpaceDAO.spaceInsert(svo);
		} catch (Exception e) {
			e.printStackTrace();
			result = 0;
		}
		return result;
	}
	
	// 공간 수정 페이지 출력
	@Override
	public SpaceVO spaceModForm(String s_name) {
		return adminSpaceDAO.spaceModForm(s_name);
	}
	
	// 공간 수정
	@Override
	public int spaceUpdate(SpaceVO svo) {
		return adminSpaceDAO.spaceUpdate(svo);
	}

}
