package com.workspace.admin.qna.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.workspace.client.qna.vo.QnaVO;

@Repository
public class AdminQnaDAOImpl implements AdminQnaDAO {

	@Autowired
	private SqlSession session;

	@Override
	// 자주묻는질문 리스트 출력
	public List<QnaVO> qnaList(Map<String, Integer> pagingMap) {
		return session.selectList("qnaList", pagingMap);
	}

	@Override
	// 전체 자주묻는질문 리스트 수 조회
	public int totQnaList() {
		return session.selectOne("totQnaList");
	}

	@Override
	// 자주묻는질문 리스트 출력(키워드 입력값으로 조회)
	public List<QnaVO> qnaListSearch(Map<String, Object> pagingMap) {
		return session.selectList("qnaListSearch", pagingMap);
	}

	@Override
	// 키워드 입력값에 맞는 자주묻는질문 리스트 수 조회
	public int qnaListCnt(Map<String, Object> pagingMap) {
		return session.selectOne("qnaListCnt", pagingMap);
	}
	
	@Override
	// 가장 최근 글번호 구하기
	public int maxQ_num() {
		return session.selectOne("maxQ_num");
	}
	
	@Override
	// 자주묻는질문 등록
	public int qnaInsert(QnaVO qvo) {
		return session.insert("qnaInsert", qvo);
	}
	
	@Override
	// 자주묻는질문 상세보기
	public QnaVO qnaDetail(int q_num) {
		return session.selectOne("qnaDetail", q_num);
	}
	
	@Override
	// 자주묻는질문 수정
	public int qnaUpdate(QnaVO qvo) {
		return session.update("qnaUpdate", qvo);
	}
	
	@Override
	// 자주묻는질문 삭제
	public int qnaDelete(QnaVO qvo) {
		return session.delete("qnaDelete", qvo);
	}
}
