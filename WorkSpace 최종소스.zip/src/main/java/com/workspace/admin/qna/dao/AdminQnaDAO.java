package com.workspace.admin.qna.dao;

import java.util.List;
import java.util.Map;

import com.workspace.client.qna.vo.QnaVO;

public interface AdminQnaDAO {
	
	// 자주묻는질문 리스트 출력
	public List<QnaVO> qnaList(Map<String, Integer> pagingMap);
	
	// 전체 자주묻는질문 리스트 수 조회
	public int totQnaList();
	
	// 자주묻는질문 리스트 출력(키워드 입력값으로 조회)
	public List<QnaVO> qnaListSearch(Map<String, Object> pagingMap);
	
	// 키워드 입력값에 맞는 자주묻는질문 리스트 수 조회
	public int qnaListCnt(Map<String, Object> pagingMap);
	
	// 가장 최근 글번호 구하기
	public int maxQ_num();
	
	// 자주묻는질문 등록
	public int qnaInsert(QnaVO qvo);
	
	// 자주묻는질문 상세보기
	public QnaVO qnaDetail(int q_num);
	
	// 자주묻는질문 수정
	public int qnaUpdate(QnaVO qvo);
	
	// 자주묻는질문 삭제
	public int qnaDelete(QnaVO qvo);

}
