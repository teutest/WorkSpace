package com.workspace.admin.qna.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.workspace.admin.qna.dao.AdminQnaDAO;
import com.workspace.client.qna.vo.QnaVO;

@Service
@Transactional
public class AdminQnaServiceImpl implements AdminQnaService {
	
	@Autowired
	private AdminQnaDAO adminQnaDAO;

	// 자주묻는질문 리스트 출력
	public Map<String, Object> qnaList(Map<String, Integer> pagingMap) {
		Map<String, Object> qnaListMap = new HashMap<String, Object>();
		
		// 자주묻는질문 리스트 출력
		List<QnaVO> qnaList = adminQnaDAO.qnaList(pagingMap);
		
		// 전체 자주묻는질문 리스트 수 조회
		int totQnaList = adminQnaDAO.totQnaList();
		
		qnaListMap.put("qnaList", qnaList);
		qnaListMap.put("totQnaList", totQnaList);	
		
		return qnaListMap;
	}
	
	// 자주묻는질문 리스트 출력(키워드 입력값으로 조회)
	public Map<String, Object> qnaListSearch(Map<String, Object> pagingMap) {
		Map<String, Object> qnaListMap = new HashMap<String, Object>();
		
		// 자주묻는질문 리스트 출력(키워드 입력값으로 조회)
		List<QnaVO> qnaList = adminQnaDAO.qnaListSearch(pagingMap);
		
		// 키워드 입력값 조건에 맞는 자주묻는질문 리스트 수 조회
		int qnaListCnt = adminQnaDAO.qnaListCnt(pagingMap);
		
		qnaListMap.put("qnaList", qnaList);
		qnaListMap.put("qnaListCnt", qnaListCnt);
		
		return qnaListMap;
	}
	
	// 자주묻는질문 등록
	public int qnaInsert(QnaVO qvo) {
		
		// 가장 최신 글번호 조회 후 1 더한 값을 글번호로 부여
		int q_num = adminQnaDAO.maxQ_num() + 1;
		qvo.setQ_num(q_num);
		
		return adminQnaDAO.qnaInsert(qvo);
	}
	
	// 자주묻는질문 상세보기
	public QnaVO qnaDetail(int q_num) {
		return adminQnaDAO.qnaDetail(q_num);
	}
	
	// 자주묻는질문 수정
	public int qnaUpdate(QnaVO qvo) {
		return adminQnaDAO.qnaUpdate(qvo);
	}
	
	// 자주묻는질문 삭제
	public int qnaDelete(QnaVO qvo) {
		return adminQnaDAO.qnaDelete(qvo);
	}

}
