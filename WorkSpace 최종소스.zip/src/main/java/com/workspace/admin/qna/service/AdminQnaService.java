package com.workspace.admin.qna.service;

import java.util.Map;

import com.workspace.client.qna.vo.QnaVO;

public interface AdminQnaService {

	// 자주묻는질문 리스트 출력
	public Map<String, Object> qnaList(Map<String, Integer> pagingMap);
	
	// 자주묻는질문 리스트 출력(키워드 입력값으로 조회)
	public Map<String, Object> qnaListSearch(Map<String, Object> pagingMap);
	
	// 자주묻는질문 등록
	public int qnaInsert(QnaVO qvo);
	
	// 자주묻는질문 상세보기
	public QnaVO qnaDetail(int q_num);
	
	// 자주묻는질문 수정
	public int qnaUpdate(QnaVO qvo);
	
	// 자주묻는질문 삭제
	public int qnaDelete(QnaVO qvo);
}
