package com.workspace.admin.qna.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.workspace.admin.qna.service.AdminQnaService;
import com.workspace.client.qna.vo.QnaVO;

@Controller
@RequestMapping(value = "/admin/qna")
public class AdminQnaController {
	
	@Autowired
	private AdminQnaService adminQnaService;
	
	// 자주묻는질문 리스트 출력
	@RequestMapping(value = "/qnaList", method = RequestMethod.GET)
	public String qnaList(HttpServletRequest request, Model model) {
		
		if(request.getSession().getAttribute("id") == null) {
			return "redirect:/admin/login";
        }
		
		String _section = request.getParameter("section");
		String _pageNum = request.getParameter("pageNum");
		
		int section = Integer.parseInt(((_section == null) ? "1" : _section));
		int pageNum = Integer.parseInt(((_pageNum == null) ? "1" : _pageNum));
		
		Map<String, Integer> pagingMap = new HashMap<String, Integer>();
		pagingMap.put("section", section);
		pagingMap.put("pageNum", pageNum);
		
		Map<String, Object> qnaListMap = adminQnaService.qnaList(pagingMap);
		qnaListMap.put("section", section);
		qnaListMap.put("pageNum", pageNum);
		
		model.addAttribute("qnaListMap", qnaListMap);
		model.addAttribute("board", "qna");
		
		return "admin/qna/adminQnaList";
	}
	
	// 자주묻는질문 리스트 출력(키워드 입력값으로 조회)
	@RequestMapping (value = "/qnaList", method = RequestMethod.POST)
	public String qnaList(@RequestParam("keyword") String keyword,
						  @RequestParam("section") String section,
						  @RequestParam("pageNum") String pageNum,
						  Model model) {
		
		Map<String, Object> pagingMap = new HashMap<String, Object>();
		pagingMap.put("section", section);
		pagingMap.put("pageNum", pageNum);
		pagingMap.put("keyword", keyword);
		
		Map<String, Object> qnaListMap = adminQnaService.qnaListSearch(pagingMap);
		qnaListMap.put("section", section);
		qnaListMap.put("pageNum", pageNum);
		qnaListMap.put("keyword", keyword); // 입력한 키워드를 그대로 jsp로 넘기기 위함
		
		model.addAttribute("qnaListMap", qnaListMap);
		model.addAttribute("board", "qna");
		
		return "admin/qna/adminQnaListAjax";
	}
	
	// 자주묻는질문 등록 폼 출력
	@RequestMapping (value = "/qnaReg", method = RequestMethod.GET)
	public String qnaReg(HttpServletRequest request, Model model) {
		
		if(request.getSession().getAttribute("id") == null) {
			return "redirect:/admin/login";
        }
		
		model.addAttribute("board", "qna");
		
		return "admin/qna/adminQnaReg";
	}
	
	// 자주묻는 질문 등록
	@RequestMapping (value = "/qnaInsert", method = RequestMethod.POST)
	public String qnaInsert(@ModelAttribute(value = "QnaVO") QnaVO qvo, Model model) {
		
		int result = adminQnaService.qnaInsert(qvo);
		
		if (result == 0) {
			model.addAttribute("msg", "자주묻는질문 등록 실패");
			model.addAttribute("url", "/admin/qna/qnaList");
		} else if (result == 1) {
			model.addAttribute("msg", "자주묻는질문 등록 성공");
			model.addAttribute("url", "/admin/qna/qnaDetail?q_num=" + qvo.getQ_num());
		}
		
		return "redirect"; // 알림창 jsp 호출
	}
	
	// 자주묻는질문 상세보기
	@RequestMapping (value = "/qnaDetail", method = RequestMethod.GET)
	public String qnaDetail(@RequestParam("q_num") String q_num,
							HttpServletRequest request,
							Model model) {
		
		if(request.getSession().getAttribute("id") == null) {
			return "redirect:/admin/login";
        }
		
		QnaVO qvo = adminQnaService.qnaDetail(Integer.parseInt(q_num));
		
		model.addAttribute("qvo", qvo);
		model.addAttribute("board", "qna");
	
		return "admin/qna/adminQnaDetail";
	}

	// 자주묻는질문 수정
	@RequestMapping (value = "/qnaMod", method = RequestMethod.POST)
	public String qnaMod(@ModelAttribute(value = "QnaVO") QnaVO qvo, Model model) {
		
		int result = adminQnaService.qnaUpdate(qvo);
		
		if (result == 0) {
			model.addAttribute("msg", "자주묻는질문 수정 실패");
			model.addAttribute("url", "/admin/qna/qnaDetail?q_num=" + qvo.getQ_num());
		} else if (result == 1) {
			model.addAttribute("msg", "자주묻는질문 수정 성공");
			model.addAttribute("url", "/admin/qna/qnaDetail?q_num=" + qvo.getQ_num());
		}
		
		return "redirect"; // 알림창 jsp 호출
	}
	
	// 자주묻는질문 삭제
	@RequestMapping (value = "/qnaDel", method = RequestMethod.POST)
	public String qnaDel(@ModelAttribute(value = "QnaVO") QnaVO qvo, Model model) {
		
		int result = adminQnaService.qnaDelete(qvo);	
		
		if (result == 0) {
			model.addAttribute("msg", "자주묻는질문 삭제 실패");
			model.addAttribute("url", "/admin/qna/qnaDetail?q_num=" + qvo.getQ_num());
		} else if (result == 1) {
			model.addAttribute("msg", "자주묻는질문 삭제 성공");
			model.addAttribute("url", "/admin/qna/qnaList");
		}
		
		return "redirect"; // 알림창 jsp 호출
	}
	
}
