package com.workspace.admin.notice.service;

import java.util.List;

import com.workspace.client.notice.vo.NoticeVO;

public interface AdminNoticeService {

	// Notice 테이블 마지막 글 번호 조회
	public int findLastNum();
	
	// 공지사항 insert
	public int noticeInsert(NoticeVO nvo);
	
	// 공지사항 리스트 
	public List<NoticeVO> adminNoticeList(NoticeVO nvo); 
	
	// 글 번호로 공지사항 조회
	public NoticeVO adminNoticeDetail(int n_num);

	// 공지사항 수정
	public int adminNoticeMod(NoticeVO nvo);

	// 전체 레코드 수 구현
	public int adminNoticeListCnt(NoticeVO nvo);

	// 공지사항 삭제
	public int noticeDel(int n_num);
}
