package com.workspace.admin.notice.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.workspace.admin.notice.service.AdminNoticeService;
import com.workspace.client.common.file.FileUploadUtil;
import com.workspace.client.common.page.Paging;
import com.workspace.client.notice.vo.NoticeVO;

@Controller
@RequestMapping(value = "/admin/notice")
public class AdminNoticeController {
	
	@Autowired
	private AdminNoticeService adminNoticeSerivice;
	
	// 공지사항 등록 페이지 출력
	@RequestMapping(value = "/noticeReg", method = RequestMethod.GET)
	public String noticeReg(Model model) {
		model.addAttribute("board", "notice");
		return "admin/notice/adminNoticeReg";
	}
	
	// 공지사항 등록
	@RequestMapping(value = "/noticeInsert", method = RequestMethod.POST)
	public String noticeInsert(@RequestParam("n_title") String n_title,
							   @RequestParam("n_content") String n_content,
							   @RequestParam("file") MultipartFile file,
							   Model model,
							   HttpServletRequest request) throws IllegalStateException, IOException {
		
		System.out.println("공지사항 등록 컨트롤러");
		
		int result = 0; // 공지사항 DB insert 실행 결과
		
		// NoticeVO 인스턴스 생성 및 필드값 설정
		NoticeVO nvo = new NoticeVO();
		nvo.setN_title(n_title);
		nvo.setN_content(n_content);
		
		// Notice 테이블 마지막 글 번호 조회 후 새로운 글 번호 생성 및 필드값 설정
		int n_num = adminNoticeSerivice.findLastNum() + 1;
		nvo.setN_num(n_num);		
		
		// 공지사항 사진 파일 업로드 후 NoticeVO 인스턴스 파일명 설정
		if (file != null) {
			String n_photo = FileUploadUtil.fileUpload(file, request, "notice");
			nvo.setN_photo(n_photo);
		}
		
		// 공지사항 DB insert 실행
		result = adminNoticeSerivice.noticeInsert(nvo);
		if (result == 1) {
			model.addAttribute("msg", "공지사항 등록 성공");
			model.addAttribute("url", "/admin/notice/noticeList"); // 등록 성공 시 공지사항 리스트로 돌아가기
		} else {
			model.addAttribute("msg", "공지사항 등록 실패");
			model.addAttribute("url", "/admin/notice/noticeReg"); // 등록 실패 시 공지사항 등록 페이지로 돌아가기
		}
		
		return "redirect";
	}
	
	// 공지사항 리스트 출력
	@RequestMapping(value = "/noticeList", method = RequestMethod.GET)
	public String noticeList(@ModelAttribute NoticeVO nvo, Model model,
							 HttpServletRequest request) {
		
		if(request.getSession().getAttribute("id") == null) {
			return "redirect:/admin/login";
        }

		int total = 0;

		// 페이지 세팅
		Paging.setPage(nvo);

		// 전체 레코드 수 구현
		total = adminNoticeSerivice.adminNoticeListCnt(nvo);

		List<NoticeVO> noticeList = adminNoticeSerivice.adminNoticeList(nvo);

		model.addAttribute("noticeList", noticeList);
		model.addAttribute("total", total);
		model.addAttribute("data", nvo);
		model.addAttribute("board", "notice");

		return "admin/notice/adminNoticeList";
	}

	// 공지사항 수정페이지
	@RequestMapping(value = "/noticeMod", method = RequestMethod.GET)
	public String modifyPage(@RequestParam("n_num") int n_num, Model model,
							 HttpServletRequest request) {
		
		if(request.getSession().getAttribute("id") == null) {
			return "redirect:/admin/login";
        }
		
		System.out.println("modify 페이지 호출 성공");

		System.out.println("선택한 글번호 : " + n_num);

		NoticeVO updateData = new NoticeVO();

		updateData = adminNoticeSerivice.adminNoticeDetail(n_num);

		updateData.setN_num(n_num);

		model.addAttribute("updateData", updateData);
		model.addAttribute("board", "notice");

		return "admin/notice/adminNoticeMod";
	}

	// 공지사항 수정
	@RequestMapping(value = "/noticeMod", method = RequestMethod.POST)
	public String updateNotice(@ModelAttribute NoticeVO nvo, @RequestParam("file") MultipartFile file, Model model,
			HttpServletRequest request) throws IllegalStateException, IOException {

		System.out.println("noticeMod 호출 성공");

		int result = 0;

		if (!file.isEmpty()) {

			if (!nvo.getN_photo().isEmpty()) {
				// 사진이 존재하면 기존 사진 삭제 후 새로 업로드함
				FileUploadUtil.fileDelete(nvo.getN_photo(), request);
			}
			nvo.setN_photo(FileUploadUtil.fileUpload(file, request, "notice"));
		}

		result = adminNoticeSerivice.adminNoticeMod(nvo);

		if (result == 1) {
			model.addAttribute("url", "/admin/notice/noticeList"); // 수정 성공하면 공지사항리스트로 이동
			model.addAttribute("msg", "공지사항 수정이 완료되었습니다.");
		} else {
			model.addAttribute("url", "/admin/notice/noticeMod");
			model.addAttribute("msg", "공지사항 수정이 실패하였습니다.");
		}

		return "redirect";
	}

	// 공지사항 삭제
	@ResponseBody
	@RequestMapping(value = "/noticeDel", method = RequestMethod.POST)
	public int noticeDel(@RequestParam("n_num")int n_num) {
		System.out.println("noticeDel 호출 성공");

		int result = 0;
		
		result = adminNoticeSerivice.noticeDel(n_num);
		
		
		return result;
	}
}
