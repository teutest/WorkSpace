package com.workspace.admin.notice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.workspace.admin.notice.dao.AdminNoticeDAO;
import com.workspace.client.notice.vo.NoticeVO;

@Service
@Transactional
public class AdminNoticeServiceImpl implements AdminNoticeService {

	@Autowired
	private AdminNoticeDAO adminNoticeDAO;
	
	// Notice 테이블 마지막 글 번호 조회
	public int findLastNum() {
		return adminNoticeDAO.findLastNum();
	}
	
	// 공지사항 insert
	public int noticeInsert(NoticeVO nvo) {
		return adminNoticeDAO.noticeInsert(nvo);
	}
	
	// 공지사항 리스트
	@Override
	public List<NoticeVO> adminNoticeList(NoticeVO nvo) {
		
		return adminNoticeDAO.adminNoticeList(nvo);
	}

	// 글 번호로 공지사항 조회
	@Override
	public NoticeVO adminNoticeDetail(int n_num) {
	
		return adminNoticeDAO.adminNoticeDetail(n_num);
	}

	// 공지사항 수정
	@Override
	public int adminNoticeMod(NoticeVO nvo) {
		
		return adminNoticeDAO.adminNoticeMod(nvo);
	}

	// 전체 레코드 수 구현
	@Override
	public int adminNoticeListCnt(NoticeVO nvo) {
		
		return adminNoticeDAO.adminNoticeListCnt(nvo);
	}

	// 공지사항 삭제
	@Override
	public int noticeDel(int n_num) {
		
		return adminNoticeDAO.noticeDel(n_num);
	}
}
