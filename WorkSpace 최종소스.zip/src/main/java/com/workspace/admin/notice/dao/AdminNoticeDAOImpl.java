package com.workspace.admin.notice.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.workspace.client.notice.vo.NoticeVO;

@Repository
public class AdminNoticeDAOImpl implements AdminNoticeDAO {

	@Autowired
	private SqlSession session;
	
	// Notice 테이블 마지막 글 번호 조회
	public int findLastNum() {
		return session.selectOne("findLastNum");
	}
	
	// 공지사항 insert
	public int noticeInsert(NoticeVO nvo) {
		return session.insert("noticeInsert", nvo);
	}
	
	// 공지사항 리스트
	@Override
	public List<NoticeVO> adminNoticeList(NoticeVO nvo) {
	
		return session.selectList("adminNoticeList",nvo);
	}

	// 공지사항 수정 데이터
	@Override
	public NoticeVO adminNoticeDetail(int n_num) {
		
		return session.selectOne("adminNoticeDetail", n_num);
	}

	// 공지사항 수정
	@Override
	public int adminNoticeMod(NoticeVO nvo) {
		
		return session.update("adminNoticeMod", nvo);
	}

	// 전체 레코드 수 구현
	@Override
	public int adminNoticeListCnt(NoticeVO nvo) {
		
		return (Integer)session.selectOne("adminNoticeListCnt", nvo);
	}

	// 공지사항 삭제
	@Override
	public int noticeDel(int n_num) {
		
		return  session.delete("noticeDel", n_num);
	}
	
}
