package com.workspace.admin.common.graph;

import java.awt.Color;
import java.awt.Font;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.workspace.client.common.file.FileUploadUtil;

public class ChartMake {
	private static Logger log = LoggerFactory.getLogger(ChartMake.class);

	public static void barChart(HttpServletRequest request, Map<String, Integer> resultMap) {
		String docRoot = request.getSession().getServletContext().getRealPath("/graph");
		FileUploadUtil.makeDir(docRoot);
		log.info("업로드할 파일 경로(docRoot) : " + docRoot);
		
		File file = new File(docRoot+"/barChart.jpg");
		FileOutputStream fos = null;
		try {
			//데이터로 사용할 카테고리 데이터 셋을 생성
			DefaultCategoryDataset dataset = new DefaultCategoryDataset();
			for (Map.Entry<String, Integer> result : resultMap.entrySet()) {
				log.info(result.getKey() + " = " + result.getValue());
				dataset.addValue(result.getValue(), result.getKey(), result.getKey());
			}

			JFreeChart chart = ChartFactory.createBarChart3D(
					"공간유형별 갱신신청률", "공간유형", "갱신신청률", dataset, 
					PlotOrientation.VERTICAL, true, true, false);
			

			chart.setBackgroundPaint(Color.white);
			chart.getTitle().setFont(new Font("맑은 고딕", Font.BOLD, 16));
			
			Font font = new Font("맑은 고딕", Font.BOLD, 12);
			chart.getLegend().setItemFont(font);
			
			CategoryPlot plot = chart.getCategoryPlot();
			// X축 라벨
			plot.getDomainAxis().setLabelFont(font);
			// X축 도메인
			plot.getDomainAxis().setTickLabelFont(font);
			// Y축 라벨
			plot.getRangeAxis().setLabelFont(font);
			// Y축 범위
			plot.getRangeAxis().setTickLabelFont(font);   
			
			fos = new FileOutputStream(file);
			ChartUtilities.writeChartAsJPEG(fos, chart, 600, 400);
		} catch (Exception e) {
			e.getMessage();
		} finally {
			try {
				if (fos != null) fos.close();
			} catch (IOException e) { e.getMessage();}
		}
	}
	
	public static void pieChart(HttpServletRequest request, Map<String, Integer> resultMap) {
		String docRoot = request.getSession().getServletContext().getRealPath("/graph");
		FileUploadUtil.makeDir(docRoot);
		log.info("업로드할 파일 경로(docRoot) : " + docRoot);
		
		File file = new File(docRoot+"/pieChart.jpg");
		FileOutputStream fos = null;
		try {
			DefaultPieDataset dataset = new DefaultPieDataset();

			for (Map.Entry<String, Integer> result : resultMap.entrySet()) {
				log.info(result.getKey() + " = " + result.getValue());
				dataset.setValue(result.getKey(), result.getValue());
			}
			// 제목, 데이터, 범례, 툴팁, url
			JFreeChart chart = ChartFactory.createPieChart("공간유형별 입주율", dataset, true, true, false);
			chart.getTitle().setFont(new Font("맑은 고딕", Font.BOLD, 16));
			chart.getLegend().setItemFont(new Font("맑은 고딕", Font.BOLD, 12));

			PiePlot plot = (PiePlot) chart.getPlot();
			plot.setBackgroundPaint(Color.white);
			plot.setOutlinePaint(Color.white);
			plot.setSectionOutlinesVisible(false);
			plot.setLabelGenerator(new StandardPieSectionLabelGenerator(
		            "{0} = {2}", NumberFormat.getNumberInstance(), NumberFormat.getPercentInstance()
			        ));
			plot.setLabelBackgroundPaint(Color.white);
			plot.setLabelFont(new Font("맑은 고딕", Font.BOLD, 14));
			
			fos = new FileOutputStream(file);
			ChartUtilities.writeChartAsJPEG(fos, chart, 600, 400);
		} catch (Exception e) {
			e.getMessage();
		} finally {
			if (fos != null) {
				try {
					fos.close();
				} catch (IOException e) { e.getMessage();}
			}
		}
	}
}
