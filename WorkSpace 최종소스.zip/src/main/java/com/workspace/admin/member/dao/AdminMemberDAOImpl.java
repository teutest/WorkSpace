package com.workspace.admin.member.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.workspace.client.member.vo.MemberVO;

@Repository
public class AdminMemberDAOImpl implements AdminMemberDAO {
	
	@Autowired
	private SqlSession session;
	
	@Override
	// 공간유형별 갱신 신청률
	public Map<String, Integer> spaceRapplyRate() {
		return session.selectOne("spaceRapplyRate", "");
	}
	
	@Override
	// 공간유형별 입주율
	public Map<String, Integer> spaceContractRate() {
		return session.selectOne("spaceContractRate", "");
	}
	
	@Override
	// 입주정보 리스트 출력(페이징 포함)
	public List<MemberVO> contractList(Map<String, Integer> pagingMap) {
		return session.selectList("contractList", pagingMap);
	}
	
	@Override
	// 전체 입주정보 리스트 수 조회
	public int totContList() {
		return session.selectOne("totContList");
	}
	
	@Override
	// 입주정보 리스트 출력(카테고리 선택값, 회사명 입력값으로 조회)
	public List<MemberVO> contractListSearch(Map<String, Object> pagingMap) {
		return session.selectList("contractListSearch", pagingMap);
	}
	
	@Override
	// 카테고리, 키워드 조건에 맞는 입주정보 리스트 수 조회
	public int contListCnt(Map<String, Object> pagingMap) {
		return session.selectOne("contListCnt", pagingMap);
	}
	
	@Override
	// 입주정보수정 - 승인완료
	public int contApproval(MemberVO mvo) {
		System.out.println("입주정보 수정 - 승인완료 DAO");
		return session.update("contApproval", mvo);
	}
	
	@Override
	// 입주정보수정 - 승인반려
	public int contDisapproval(MemberVO mvo) {
		System.out.println("입주정보 수정 - 승인반려 DAO");
		return session.update("contDisapproval", mvo);
	}
	
	@Override
	// 입주정보수정 - 승인대기
	public int contReady(MemberVO mvo) {
		System.out.println("입주정보 수정 - 승인대기 DAO");
		return session.update("contReady", mvo);
	}
	
	@Override
	// 입주승인 대기로 변경할 경우 공간 '사용중'으로 다시 변경
	public int s_stateReInUse(String s_name) {
		System.out.println("공간 '사용중'으로 변경 DAO");
		return session.update("s_stateReInUse", s_name);
	}
	
	@Override
	// 입주정보 리스트에서 담당자 정보 팝업 내용 조회
	public MemberVO u_contactInfo(String u_id) {
		return session.selectOne("u_contactInfo", u_id);
	}
	
	@Override
	// 입주정보 리스트에서 갱신정보 팝업 내용 조회
	public MemberVO renewalInfo(String u_id) {
		return session.selectOne("renewalInfo", u_id);
	}
	
	@Override
	// 입주정보수정 - 갱신승인
	public int renewalApproval(MemberVO mvo) {
		return session.update("renewalApproval", mvo);
	}
	
	@Override
	// 입주정보 리스트에서 계약 취소 정보 팝업 내용 조회
	public MemberVO withdrawalInfo(String u_id) {
		return session.selectOne("withdrawalInfo", u_id);
	}
	
	@Override
	// 입주정보수정 - 취소승인
	public int withdrawalApproval(MemberVO mvo) {
		return session.update("withdrawalApproval", mvo);
	}
	
	@Override
	// 갱신여부 메일 발송 리스트 팝업 내용 조회
	public List<MemberVO> renewalMailList(Map<String, Integer> pagingMap) {
		return session.selectList("renewalMailList", pagingMap);
	}
	
	@Override
	// 갱신여부 메일 발송 대상 수 조회
	public int totRenewalMailList() {
		return session.selectOne("totRenewalMailList");
	}
	
	// 회원 리스트 출력
	@Override
	public List<MemberVO> memberList(MemberVO mvo) {
		
		return session.selectList("memberList", mvo);
		
	}
	
	// 회원 비활성화 처리
	@Override
	public int deactivated(MemberVO mvo) {
		
		return session.update("deactivated", mvo);
	}

	// 전체 레코드 수
	@Override
	public int memberListCnt(MemberVO mvo) {
	
		return (Integer)session.selectOne("memberListCnt");
	}
	
}
