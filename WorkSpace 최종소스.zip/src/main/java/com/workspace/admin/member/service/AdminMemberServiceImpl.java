package com.workspace.admin.member.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.mail.HtmlEmail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.workspace.admin.member.dao.AdminMemberDAO;
import com.workspace.admin.space.dao.AdminSpaceDAO;
import com.workspace.client.member.vo.MemberVO;

@Service
@Transactional
public class AdminMemberServiceImpl implements AdminMemberService {
	
	@Autowired
	private AdminMemberDAO adminMemberDAO;
	
	@Autowired
	private AdminSpaceDAO adminSpaceDAO;
	
	@Override
	// 공간유형별 입주율
	public Map<String, Integer> spaceContractRate() {
		return adminMemberDAO.spaceContractRate();
	}
	
	@Override
	// 공간유형별 갱신 신청률
	public Map<String, Integer> spaceRapplyRate() {
		return adminMemberDAO.spaceRapplyRate();
	}
	
	@Override
	// 입주정보 리스트 출력
	public Map<String, Object> contractList(Map<String, Integer> pagingMap) {
		Map<String, Object> contListMap = new HashMap<String, Object>();
		
		// 입주정보 리스트 출력(페이징 포함)
		List<MemberVO> contList = adminMemberDAO.contractList(pagingMap);
		
		// 전체 입주정보 리스트 수 조회
		int totContList = adminMemberDAO.totContList();
		
		contListMap.put("contList", contList);
		contListMap.put("totContList", totContList);	
		
		return contListMap;
	}
	
	@Override
	// 입주정보 리스트 출력(카테고리 선택값, 회사명 입력값으로 조회)
	public Map<String, Object> contractListSearch(Map<String, Object> pagingMap) {
		Map<String, Object> contListMap = new HashMap<String, Object>();
		
		// section값이 section이고 pageNum값이 pageNum인 입주정보 리스트 가져오기
		List<MemberVO> contList = adminMemberDAO.contractListSearch(pagingMap);
		
		// 카테고리, 키워드 조건에 맞는 입주정보 리스트 수 조회
		int contListCnt = adminMemberDAO.contListCnt(pagingMap);
		
		contListMap.put("contList", contList);
		contListMap.put("contListCnt", contListCnt);
		
		return contListMap;
	}
	
	@Override
	// 입주정보수정 - 승인완료
	public int contApproval(MemberVO mvo) {
		System.out.println("입주정보 수정 - 승인완료 서비스");
		return adminMemberDAO.contApproval(mvo);
	}
	
	@Override
	// 입주정보수정 - 승인반려
	public int contDisapproval(MemberVO mvo) {
		System.out.println("입주정보 수정 - 승인반려 서비스");
		try {
			if (adminMemberDAO.contDisapproval(mvo) == 1) {
				if (adminSpaceDAO.s_stateUsable(mvo.getS_name()) == 1) {
					return 1; // 승인반려 수정 성공
				} else {
					return 0; // 승인반려 수정 실패(공간 사용현황 변경 실패)
				}
			} else {
				return 0; // 승인반려 수정 실패
			}
		} catch (Exception e) {
			e.printStackTrace();
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return 0; // 승인반려 수정 실패(예외 발생)
		}	
	}
	
	@Override
	// 입주정보수정 - 승인대기
	public int contReady(MemberVO mvo) {
		System.out.println("입주정보 수정 - 승인대기 서비스");
		try {
			if (adminMemberDAO.contReady(mvo) == 1) {
				if (adminMemberDAO.s_stateReInUse(mvo.getS_name()) == 1) {
					return 1; // 승인대기 수정 성공
				} else {
					return 0; // 승인대기 수정 실패(공간 사용현황 변경 실패)
				}
			} else {
				return 0; // 승인대기 수정 실패
			}
		} catch (Exception e) {
			e.printStackTrace();
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return 0; // 승인대기 수정 실패(예외 발생)
		}	
	}
	
	@Override
	// 입주정보 리스트에서 담당자 정보 팝업 내용 조회
	public MemberVO u_contactInfo(String u_id) {
		return adminMemberDAO.u_contactInfo(u_id);
	}
	
	@Override
	// 입주정보 리스트에서 갱신정보 팝업 내용 조회
	public MemberVO renewalInfo(String u_id) {
		return adminMemberDAO.renewalInfo(u_id);
	}
	
	@Override
	// 입주정보수정 - 갱신승인
	public int renewalApproval(MemberVO mvo) {
		return adminMemberDAO.renewalApproval(mvo);
	}
	
	@Override
	// 입주정보 리스트에서 계약 취소 정보 팝업 내용 조회
	public MemberVO withdrawalInfo(String u_id) {
		return adminMemberDAO.withdrawalInfo(u_id);
	}
	
	@Override
	// 입주정보수정 - 취소승인
	public int withdrawalApproval(MemberVO mvo) {
		return adminMemberDAO.withdrawalApproval(mvo);
	}
	
	@Override
	// 갱신여부 메일 발송 리스트 팝업 내용 조회
	public Map<String, Object> renewalMailList(Map<String, Integer> pagingMap) {
		Map<String, Object> renewalMailListMap = new HashMap<String, Object>();
		
		// 갱신여부 메일 발송 리스트 조회
		List<MemberVO> renewalMailList = adminMemberDAO.renewalMailList(pagingMap);
		
		// 갱신여부 메일 발송 대상 수 조회
		int totRenewalMailList = adminMemberDAO.totRenewalMailList();
		
		renewalMailListMap.put("renewalMailList", renewalMailList);
		renewalMailListMap.put("totRenewalMailList", totRenewalMailList);	
		
		return renewalMailListMap;
	}
	
	// 갱신여부 메일 발송 처리
	@Override
	public int sendRenewalMail(MemberVO mvo, long diffDays) {
		
		// Mail Server 설정
		String charSet = "utf-8";
		String hostSMTP = "smtp.gmail.com";
		String hostSMTPid = "teutest2011@gmail.com";
		String hostSMTPpwd = "zzmnpwaljzjvwglc";

		// 보내는 사람 이메일 주소
		String fromEmail = "teutest2011@gmail.com";
		
		// 받는 사람 이메일 주소
		String mail = mvo.getU_email();
		
		// 보내는 사람 이름, 메일 제목, 메일 내용
		String fromName = "WorkSpace";
		String subject = "[WorkSpace] 입주 갱신 안내 메일";
		String msg = "";
		
		msg += "<div>";
		msg += "<h1>" + mvo.getComp_name() + " 입주 갱신 안내 메일</h1><br>";
		msg += "안녕하세요. " + mvo.getComp_name() + " 담당자님!<br>";
		msg += "WorkSpace 관리자입니다.<br><br>";
		msg += mvo.getComp_name() + "의 계약 만료일이 " + diffDays + "일 남았습니다.<br><br>"; 
		msg += "계약 갱신을 원하실 경우 <a href='http://localhost:8080/'>WorkSpace 홈페이지</a> > 마이페이지 > 입주정보 메뉴에 접속하셔서 ";
		msg += "갱신 개월수 선택 및 갱신 신청을 완료해주시기 바랍니다.<br><br>";
		msg += "본 메일은 갱신 신청 또는 계약 만료일 전까지 매일 발송될 예정입니다.<br>";
		msg += "궁금하신 사항은 고객센터로 연락주시면 친절하게 안내드리겠습니다.<br><br>";
		msg += "고맙습니다.<br>";
		msg += "WorkSpace 관리자 드림.";
		msg += "</div>";

		try {
			HtmlEmail email = new HtmlEmail();
			email.setDebug(true);
			email.setCharset(charSet);
			email.setSSL(true);
			email.setHostName(hostSMTP);
			email.setSmtpPort(465);

			email.setAuthentication(hostSMTPid, hostSMTPpwd);
			email.setTLS(true);
			email.addTo(mail, charSet);
			email.setFrom(fromEmail, fromName, charSet);
			email.setSubject(subject);
			email.setHtmlMsg(msg);
			email.send();
			
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	// 회원 정보 리스트 출력
	@Override
	public List<MemberVO> memberList(MemberVO mvo) {
		
		return adminMemberDAO.memberList(mvo);
	}
	
	// 회원 비활성화 처리
	@Transactional
	@Override
	public int deactivated(MemberVO mvo) {
		
		return adminMemberDAO.deactivated(mvo);
		
	}
	
	// 전체 레코드 수 
	@Override
	public int MemberListCnt(MemberVO mvo) {
		
		return adminMemberDAO.memberListCnt(mvo);
	}

}
