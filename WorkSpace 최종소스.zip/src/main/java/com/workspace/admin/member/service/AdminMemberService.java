package com.workspace.admin.member.service;

import java.util.List;
import java.util.Map;

import com.workspace.client.member.vo.MemberVO;

public interface AdminMemberService {
	
	// 공간유형별 입주율
	public Map<String, Integer> spaceContractRate();
	
	// 공간유형별 갱신 신청률
	public Map<String, Integer> spaceRapplyRate();
	
	// 입주정보 리스트 출력
	public Map<String, Object> contractList(Map<String, Integer> pagingMap);
	
	// 입주정보 리스트 출력(카테고리 선택값, 회사명 입력값으로 조회)
	public Map<String, Object> contractListSearch(Map<String, Object> pagingMap);
	
	// 입주정보수정 - 승인완료
	public int contApproval(MemberVO mvo);
	
	// 입주정보수정 - 승인반려
	public int contDisapproval(MemberVO mvo);
	
	// 입주정보수정 - 승인대기
	public int contReady(MemberVO mvo);
	
	// 입주정보 리스트에서 담당자 정보 팝업 내용 조회
	public MemberVO u_contactInfo(String u_id);
	
	// 입주정보 리스트에서 갱신정보 팝업 내용 조회
	public MemberVO renewalInfo(String u_id);
	
	// 입주정보수정 - 갱신승인
	public int renewalApproval(MemberVO mvo);
	
	// 입주정보 리스트에서 계약 취소 정보 팝업 내용 조회
	public MemberVO withdrawalInfo(String u_id);
	
	// 입주정보수정 - 취소승인
	public int withdrawalApproval(MemberVO mvo);
	
	// 갱신여부 메일 발송 리스트 팝업 내용 조회
	public Map<String, Object> renewalMailList(Map<String, Integer> pagingMap);
	
	// 갱신여부 메일 발송 처리
	public int sendRenewalMail(MemberVO mvo, long diffDays);
	
	// 회원 정보 리스트 출력
	public List<MemberVO> memberList(MemberVO mvo);
	
	// 회원 비활성화 처리
	public int deactivated(MemberVO mvo);
	
	// 전체 레코드 수
	public int MemberListCnt(MemberVO mvo);
}
