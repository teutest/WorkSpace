package com.workspace.admin.member.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.workspace.admin.common.graph.ChartMake;
import com.workspace.admin.member.service.AdminMemberService;
import com.workspace.client.common.page.Paging;
import com.workspace.client.member.vo.MemberListVO;
import com.workspace.client.member.vo.MemberVO;

@Controller
@RequestMapping(value = "/admin/member")
public class AdminMemberController {
	
	@Autowired
	private AdminMemberService adminMemberService;

	// 입주정보 리스트 출력
	@RequestMapping(value = "/contractInfo", method = RequestMethod.GET)
	public String contractInfo(HttpServletRequest request, Model model) {		
		if(request.getSession().getAttribute("id") == null) {
			return "redirect:/admin/login";
        }
		
		// 공간유형별 입주율
		Map<String, Integer> spaceRenewalRate = adminMemberService.spaceContractRate();
		ChartMake.pieChart(request, spaceRenewalRate);
		
		// 공간유형별 갱신 신청률
		Map<String, Integer> spaceRapplyRate = adminMemberService.spaceRapplyRate();
		ChartMake.barChart(request, spaceRapplyRate);
		
		String _section = request.getParameter("section");
		String _pageNum = request.getParameter("pageNum");
		
		int section = Integer.parseInt(((_section == null) ? "1" : _section));
		int pageNum = Integer.parseInt(((_pageNum == null) ? "1" : _pageNum));
		
		Map<String, Integer> pagingMap = new HashMap<String, Integer>();
		pagingMap.put("section", section);
		pagingMap.put("pageNum", pageNum);
		
		Map<String, Object> contListMap = adminMemberService.contractList(pagingMap);
		contListMap.put("section", section);
		contListMap.put("pageNum", pageNum);
		
		model.addAttribute("contListMap", contListMap);		
		
		return "admin/member/contractInfo";
	}
	
	// 입주정보 리스트 출력(카테고리 선택값, 회사명 입력값으로 조회)
	@RequestMapping (value = "/contractInfo", method = RequestMethod.POST)
	public String contractInfo(@RequestParam("cont_state") String cont_state,
							   @RequestParam("r_apply") String r_apply,
							   @RequestParam("w_apply") String w_apply,
							   @RequestParam("w_state") String w_state,
							   @RequestParam("comp_name") String comp_name,
							   @RequestParam("section") String section,
							   @RequestParam("pageNum") String pageNum,
							   Model model) {
		
		Map<String, Object> pagingMap = new HashMap<String, Object>();
		pagingMap.put("section", section);
		pagingMap.put("pageNum", pageNum);
		pagingMap.put("cont_state", cont_state);
		pagingMap.put("r_apply", r_apply);
		pagingMap.put("w_apply", w_apply);
		pagingMap.put("w_state", w_state);
		pagingMap.put("comp_name", comp_name);
		
		Map<String, Object> contListMap = adminMemberService.contractListSearch(pagingMap);
		contListMap.put("section", section);
		contListMap.put("pageNum", pageNum);
		contListMap.put("cont_state", cont_state); // 선택한 카테고리를 그대로 jsp로 넘기기 위함
		contListMap.put("r_apply", r_apply); // 선택한 카테고리를 그대로 jsp로 넘기기 위함
		contListMap.put("w_apply", w_apply); // 선택한 카테고리를 그대로 jsp로 넘기기 위함
		contListMap.put("w_state", w_state); // 선택한 카테고리를 그대로 jsp로 넘기기 위함
		contListMap.put("comp_name", comp_name); // 입력한 키워드를 그대로 jsp로 넘기기 위함
		
		model.addAttribute("contListMap", contListMap);
		
		return "admin/member/adminContractInfoAjax";
	}
	
	// 입주정보 수정(승인완료, 승인반려, 승인대기, 갱신승인, 취소승인)
	@RequestMapping(value = "/contractUpdate", method = RequestMethod.POST)
	public String contractUpdate(@ModelAttribute(value = "MemberListVO") MemberListVO memberListVO, Model model) {
		
		List<MemberVO> contList = memberListVO.getMemberList();
		MemberVO mvo = new MemberVO();
		int result = 0;
		
		for (int i = 0; i < contList.size(); i++) {
			mvo = contList.get(i);
			
			if (mvo.getCont_state().equals("승인완료") && mvo.getR_state() == null && mvo.getW_state() == null) {
				// 입주승인하는 경우
				if (adminMemberService.contApproval(mvo) == 1) {
					result = 1;
				} else {
					result = 0;
					break;
				}
			} else if (!(mvo.getCont_state().equals("승인완료")) && mvo.getR_state() == null && mvo.getW_state() == null) {
				if (mvo.getCont_state().equals("승인반려")) {
					// 입주승인 반려하는 경우
					if (adminMemberService.contDisapproval(mvo) == 1) {
						result = 1;
					} else {
						result = 0;
						break;
					}
				} else if (mvo.getCont_state().equals("승인대기")) {
					// 입주승인 반려 후 다시 승인대기 상태로 전환하는 경우
					if (adminMemberService.contReady(mvo) == 1) {
						result = 1;
					} else {
						result = 0;
						break;
					}
				}
			} else if (mvo.getCont_state().equals("승인완료") && mvo.getR_state().equals("갱신승인완료") && mvo.getW_state().equals("공간취소대기")) {
				// 갱신승인하는 경우
				if (adminMemberService.renewalApproval(mvo) == 1) {
					result = 1;
				} else {
					result = 0;
					break;
				}
			} else if (mvo.getCont_state().equals("승인완료") && mvo.getR_state().equals("갱신승인대기") && mvo.getW_state().equals("공간취소완료")) {
				// 취소승인하는 경우
				if (adminMemberService.withdrawalApproval(mvo) == 1) {
					result = 1;
				} else {
					result = 0;
					break;
				}
			} else {
				result = 1;
			}
		}
		
		if (result == 0) {
			model.addAttribute("msg", "저장 오류");
			model.addAttribute("url", "/admin/member/contractInfo");
		} else if (result == 1) {
			model.addAttribute("msg", "저장 성공");
			model.addAttribute("url", "/admin/member/contractInfo");
		}
		
		return "redirect"; // 알림창 jsp 호출
	}
	
	// 입주정보 리스트에서 담당자 정보 팝업 내용 조회
	@RequestMapping(value = "/u_contactInfo", method = RequestMethod.GET)
	public String u_contactInfo(@RequestParam("u_id") String u_id, Model model) {
		
		MemberVO u_contactInfo = adminMemberService.u_contactInfo(u_id);
		
		model.addAttribute("u_contactInfo", u_contactInfo);
		
		return "admin/member/adminUserContactInfo"; // 담당자 정보 팝업창
	}
	
	// 입주정보 리스트에서 계약 갱신 정보 팝업 내용 조회
	@RequestMapping(value = "/contRenewal", method = RequestMethod.GET)
	public String contRenewal(@RequestParam("u_id") String u_id,
							  @RequestParam("no") String no,
							  Model model) {
		
		MemberVO renewalInfo = adminMemberService.renewalInfo(u_id);
		
		model.addAttribute("renewalInfo", renewalInfo);
		model.addAttribute("no", no);
		
		return "admin/member/adminContRenewal"; // 갱신정보 팝업창
	}
	
	// 입주정보 리스트에서 계약 취소 정보 팝업 내용 조회
	@RequestMapping(value = "/contWithdrawal", method = RequestMethod.GET)
	public String contWithdrawal(@RequestParam("u_id") String u_id,
							     @RequestParam("no") String no,
							     Model model) {
		
		MemberVO withdrawalInfo = adminMemberService.withdrawalInfo(u_id);
		
		model.addAttribute("withdrawalInfo", withdrawalInfo);
		model.addAttribute("no", no);
		
		return "admin/member/adminContWithdrawal"; // 취소정보 팝업창
	}
	
	// 갱신여부 메일 발송 리스트 팝업 내용 조회
	@RequestMapping(value = "/renewalMailList", method = RequestMethod.GET)
	public String renewalMailList(HttpServletRequest request, Model model) {
		
		String _section = request.getParameter("section");
		String _pageNum = request.getParameter("pageNum");
		
		int section = Integer.parseInt(((_section == null) ? "1" : _section));
		int pageNum = Integer.parseInt(((_pageNum == null) ? "1" : _pageNum));
		
		Map<String, Integer> pagingMap = new HashMap<String, Integer>();
		pagingMap.put("section", section);
		pagingMap.put("pageNum", pageNum);
		
		Map<String, Object> renewalMailListMap = adminMemberService.renewalMailList(pagingMap);
		renewalMailListMap.put("section", section);
		renewalMailListMap.put("pageNum", pageNum);
		
		model.addAttribute("renewalMailListMap", renewalMailListMap);
		
		return "admin/member/renewalMailList"; // 갱신여부 메일 발송 리스트 팝업창
	}
	
	// 갱신여부 메일 발송 처리
	@ResponseBody
	@RequestMapping(value = "/sendRenewalMail", method = RequestMethod.POST)
	public String sendRenewalMail(@RequestParam(value = "s_nameArr[]") List<String> s_nameArr,
								  @RequestParam(value = "comp_nameArr[]") List<String> comp_nameArr,
								  @RequestParam(value = "end_dateArr[]") List<String> end_dateArr,
								  @RequestParam(value = "u_emailArr[]") List<String> u_emailArr) throws ParseException {
		
		System.out.println("갱신여부 메일 발송 처리 컨트롤러");
		
		MemberVO mvo = new MemberVO();
		int result = 0;
		int resultValue = 0;
		
		for (int i = 0; i < s_nameArr.size(); i++) {
			mvo.setS_name(s_nameArr.get(i));
			mvo.setComp_name(comp_nameArr.get(i));
			mvo.setEnd_date(end_dateArr.get(i));
			mvo.setU_email(u_emailArr.get(i));
			
			// 계약만료일까지 남은 일수 계산
			Calendar today = Calendar.getInstance();
			today.setTime(new Date()); // 오늘날짜
			
			Date date = new SimpleDateFormat("yyyy-MM-dd").parse(mvo.getEnd_date());
			Calendar compareDate = Calendar.getInstance();
			compareDate.setTime(date); // 계약만료일
			
			long diffSec = (compareDate.getTimeInMillis() - today.getTimeInMillis()) / 1000;
			long diffDays = diffSec / (24 * 60 * 60) + 1; // 계약만료일까지 남은 일수
			
			result += adminMemberService.sendRenewalMail(mvo, diffDays);
		}
		
		if (result == s_nameArr.size()) {
			System.out.println("메일 발송 성공");
			resultValue = 1;
		} else {
			System.out.println("메일 발송 오류 발생");
			resultValue = 0;
		}
		
		return resultValue + "";
	}
	
	// 회원정보 리스트 출력
	@RequestMapping(value = "/memberList", method = RequestMethod.GET)
	public String memberList(@ModelAttribute MemberVO mvo, Model model,
							 HttpServletRequest request) {
		
		if(request.getSession().getAttribute("id") == null) {
			return "redirect:/admin/login";
        }
		
		int total = 0;
		
		// 페이지 세팅
		Paging.setPage(mvo);
		
		List<MemberVO> memberList = adminMemberService.memberList(mvo);
		 
		 if (mvo.getKeyword() == "") {
				
			 // 전체 레코드 수 구현
			 total = adminMemberService.MemberListCnt(mvo);

				/*
				 * // 글번호 재설정 count = total - (Util.nvl(nvo.getPage()) - 1) *
				 * Util.nvl(nvo.getPageSize()); System.out.println("count = " + count);
				 */
			} else {

				// 페이지 세팅
				Paging.setPage(mvo);

				// 전체 레코드 수 구현
				int start_row = Integer.parseInt(mvo.getStart_row());
				int end_row = Integer.parseInt(mvo.getEnd_row());
				
				total = end_row - start_row; 

			}

		model.addAttribute("memberList", memberList);
		model.addAttribute("total", total);
		model.addAttribute("data", mvo);
		
		return "admin/member/memberList";
	}
	
	// 회원 비활성화 처리
	@ResponseBody
	@RequestMapping(value = "/deactivated", method = RequestMethod.POST)
	public int deactivated(@RequestParam("u_id") String u_id, @RequestParam("deactivated") String deactivated) {
		int result = 0;
		
		MemberVO mvo = new MemberVO();
		
		mvo.setU_id(u_id);
		
		if(deactivated.equals("비활성화")) {	// 비활성화 버튼 눌렀을 경우
			mvo.setDeactivated("Y");
			
			result = adminMemberService.deactivated(mvo);
		} 
		if(deactivated.equals("비활성화 취소")) {	// 비활성화 취소 버튼 눌렀을 경우
			mvo.setDeactivated("N");
			
			result = adminMemberService.deactivated(mvo);
			
		}
		
		return result;
	}
	
}