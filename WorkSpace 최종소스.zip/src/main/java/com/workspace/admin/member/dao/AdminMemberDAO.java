package com.workspace.admin.member.dao;

import java.util.List;
import java.util.Map;

import com.workspace.client.member.vo.MemberVO;

public interface AdminMemberDAO {
	
	// 공간유형별 입주율
	public Map<String, Integer> spaceContractRate();
	
	// 공간유형별 갱신 신청률
	public Map<String, Integer> spaceRapplyRate();
	
	// 입주정보 리스트 출력
	public List<MemberVO> contractList(Map<String, Integer> pagingMap);
	
	// 전체 입주정보 리스트 수 조회
	public int totContList();
	
	// 입주정보 리스트 출력(카테고리 선택값, 회사명 입력값으로 조회)
	public List<MemberVO> contractListSearch(Map<String, Object> pagingMap);
	
	// 카테고리, 키워드 조건에 맞는 입주정보 리스트 수 조회
	public int contListCnt(Map<String, Object> pagingMap);
	
	// 입주정보수정 - 승인완료
	public int contApproval(MemberVO mvo);
	
	// 입주정보수정 - 승인반려
	public int contDisapproval(MemberVO mvo);
		
	// 입주정보수정 - 승인대기
	public int contReady(MemberVO mvo);
	
	// 입주승인 대기로 변경할 경우 공간 '사용중'으로 다시 변경
	public int s_stateReInUse(String s_name);
	
	// 입주정보 리스트에서 담당자 정보 팝업 내용 조회
	public MemberVO u_contactInfo(String u_id);
	
	// 입주정보 리스트에서 갱신정보 팝업 내용 조회
	public MemberVO renewalInfo(String u_id);
	
	// 입주정보수정 - 갱신승인
	public int renewalApproval(MemberVO mvo);
	
	// 입주정보 리스트에서 계약 취소 정보 팝업 내용 조회
	public MemberVO withdrawalInfo(String u_id);
	
	// 입주정보수정 - 취소승인
	public int withdrawalApproval(MemberVO mvo);
	
	// 갱신여부 메일 발송 리스트 팝업 내용 조회
	public List<MemberVO> renewalMailList(Map<String, Integer> pagingMap);
	
	// 갱신여부 메일 발송 대상 수 조회
	public int totRenewalMailList();
	
	// 회원 정보 리스트
	public List<MemberVO> memberList(MemberVO mvo);

	// 회원 비활성화 처리
	public int deactivated(MemberVO mvo);

	// 전체 레코드 수 
	public int memberListCnt(MemberVO mvo);
	
}
